import plotly.graph_objects as go
import streamlit as st

import common as c

c.setup_page("MRP Planning", "🧮")
res = c.header("MRP Planning", "Net requirements, planned orders, shortage alerts and supplier lead times")
mrp = res["mrp"]
mats = res["data"]["materials"].set_index("material_id")
orders = mrp.planned_orders.copy()

tabs = st.tabs(["Shortage alerts", "Planned orders", "MRP grid (per material)"])

with tabs[0]:
    sh = mrp.shortages.copy()
    if sh.empty:
        st.success("No shortage alerts for the current plan.")
    else:
        sev = st.multiselect("Severity", ["Critical", "High", "Warning"], default=["Critical", "High", "Warning"])
        sh = sh[sh["severity"].isin(sev)]
        names = res["data"]["suppliers"].set_index("supplier_id")["name"]
        sh["supplier"] = sh["supplier_id"].map(names)
        for col in ("need_date", "earliest_possible_date"):
            sh[col] = sh[col].dt.strftime("%d %b %Y")
        st.caption("Lead-time violation: the planned order should already have been released, so supply cannot arrive "
                   "by the need date without expediting. Below safety stock: current on-hand is under the safety level.")
        st.dataframe(sh.drop(columns="supplier_id"), hide_index=True)

with tabs[1]:
    c1, c2, c3 = st.columns(3)
    otype = c1.multiselect("Order type", sorted(orders["order_type"].unique()), default=sorted(orders["order_type"].unique()))
    only_late = c2.checkbox("Past-due only", False)
    mt = c3.multiselect("Material", sorted(orders["material_id"].unique()))
    f = orders[orders["order_type"].isin(otype)]
    if only_late:
        f = f[f["past_due"]]
    if mt:
        f = f[f["material_id"].isin(mt)]
    f = f.copy()
    f["period"] = f["period_start"].dt.strftime("%b %Y")
    for col in ("need_date", "release_date"):
        f[col] = f[col].dt.strftime("%d %b %Y")
    st.dataframe(f[["planned_order_id", "material_id", "description", "order_type", "period", "quantity", "uom",
                    "release_date", "need_date", "lead_time_days", "supplier_id", "past_due", "value"]].round(0),
                 hide_index=True)
    st.metric("Total planned purchase value", c.money(orders.loc[orders["order_type"] == "Purchase Requisition", "value"].sum()))
    c.download_button(orders, "mrp_planned_orders.csv", "dl_po")

with tabs[2]:
    mat = st.selectbox("Material", sorted(mats.index), format_func=lambda m: f"{m} - {mats.loc[m, 'description']}")
    g = mrp.grid[mrp.grid["material_id"] == mat].copy()
    info = mats.loc[mat]
    st.caption(f"Procurement: {info['procurement_type']} | lot rule: {info['lot_size_rule']} "
               f"({info['lot_size']:.0f}) | lead time: {info['lead_time_days']} days | "
               f"safety stock: {info['safety_stock']:.0f} | supplier: {info['supplier_id'] or '-'}")
    x = g["period_start"].dt.strftime("%b %Y")
    fig = go.Figure()
    fig.add_bar(x=x, y=g["gross_requirement"], name="Gross requirement")
    fig.add_bar(x=x, y=g["scheduled_receipts"], name="Scheduled receipts")
    fig.add_bar(x=x, y=g["planned_receipt"], name="Planned receipt")
    fig.add_scatter(x=x, y=g["projected_stock"], name="Projected stock", mode="lines+markers")
    fig.add_scatter(x=x, y=g["safety_stock"], name="Safety stock", mode="lines", line=dict(dash="dash"))
    fig.update_layout(barmode="group", title=f"MRP view - {mat}")
    st.plotly_chart(c.style_fig(fig, 420))
    st.dataframe(c.fmt_period(g).round(0), hide_index=True)
