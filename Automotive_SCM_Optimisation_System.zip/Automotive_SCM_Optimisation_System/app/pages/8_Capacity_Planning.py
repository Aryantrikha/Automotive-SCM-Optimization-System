import pandas as pd
import plotly.express as px
import streamlit as st

import common as c
from automotive_scm import capacity

c.setup_page("Capacity Planning", "⚙️")
res = c.header("Capacity Planning", "Required vs available hours, utilisation, over-capacity alerts and load balancing")
t = res["config"]["thresholds"]
base, opt = res["capacity_util_baseline"], res["capacity_util_optimised"]

view = st.radio("Plan view", ["Baseline (primary work centres)", "Optimised (load balanced)"], horizontal=True)
util = (base if view.startswith("Baseline") else opt).copy()
plants = st.multiselect("Plant", sorted(util["plant_id"].unique()), default=sorted(util["plant_id"].unique()))
util = util[util["plant_id"].isin(plants)]
util["period"] = util["period_start"].dt.strftime("%b %Y")

m = st.columns(4)
m[0].metric("Average utilisation", f"{util['utilisation'].mean():.0%}")
m[1].metric("Peak utilisation", f"{util['utilisation'].max():.0%}")
m[2].metric("Overloaded WC-months", int((util["status"] == "Overloaded").sum()))
m[3].metric("Warning WC-months", int((util["status"] == "Warning").sum()))

order = [p.strftime("%b %Y") for p in res["periods"]]
piv = util.pivot(index="name", columns="period", values="utilisation")[order] * 100
fig = px.imshow(piv, aspect="auto", color_continuous_scale="RdYlGn_r", zmin=0, zmax=130, text_auto=".0f",
                title=f"Utilisation % - {view.split(' (')[0]} (warning {t['capacity_warning']:.0%}, overload {t['capacity_overload']:.0%})")
st.plotly_chart(c.style_fig(fig, 560))

st.subheader("Required vs available hours")
wc = st.selectbox("Work centre", sorted(util["name"].unique()))
w = util[util["name"] == wc]
fig = px.bar(w, x="period", y="required_hours", title=wc, labels={"period": "", "required_hours": "Hours"})
fig.add_scatter(x=w["period"], y=w["available_hours"], mode="lines+markers", name="Available hours")
st.plotly_chart(c.style_fig(fig, 340))

st.subheader("Over-capacity alerts (baseline)")
al = res["capacity_alerts"].copy()
if al.empty:
    st.success("No overloaded work centres in the baseline plan.")
else:
    al["period_start"] = al["period_start"].dt.strftime("%b %Y")
    al["utilisation"] = (al["utilisation"] * 100).round(0).astype(int).astype(str) + "%"
    st.dataframe(al.round(1), hide_index=True)

st.subheader("Optimisation result: peak utilisation by work centre")
cmp_ = capacity.compare_utilisation(base, opt)
cmp_ = cmp_[cmp_["name"].isin(util["name"].unique())]
long = cmp_.melt(id_vars=["work_centre_id", "name"], value_vars=["peak_before", "peak_after"], var_name="plan",
                 value_name="peak_utilisation")
long["plan"] = long["plan"].map({"peak_before": "Baseline", "peak_after": "Optimised"})
fig = px.bar(long, x="peak_utilisation", y="name", color="plan", barmode="group", orientation="h",
             labels={"name": "", "peak_utilisation": "Peak utilisation"})
fig.add_vline(x=1.0, line_dash="dash", line_color="red")
st.plotly_chart(c.style_fig(fig, 640))
moved = res["capacity_assignments"]
moved = moved[moved["assigned_work_centre"] != moved["primary_work_centre"]]
st.caption("Orders (or parts of orders) moved to an alternative work centre of the same capability group and plant. "
           "Alternates may be slower, so hours increase when work moves.")
st.dataframe(moved.assign(period_start=moved["period_start"].dt.strftime("%b %Y")).round(1), hide_index=True)
