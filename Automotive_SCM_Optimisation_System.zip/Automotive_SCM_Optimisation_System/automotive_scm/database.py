"""SQLite persistence for master data and planning results."""
from __future__ import annotations

import sqlite3
from pathlib import Path

import pandas as pd

# DDL for master-data tables (documented in docs/data_dictionary.md).
SCHEMA_DDL = {
    "plants": """CREATE TABLE plants (plant_id TEXT PRIMARY KEY, name TEXT NOT NULL, location TEXT)""",
    "uom": """CREATE TABLE uom (uom TEXT PRIMARY KEY, description TEXT, dimension TEXT)""",
    "suppliers": """CREATE TABLE suppliers (supplier_id TEXT PRIMARY KEY, name TEXT NOT NULL, country TEXT,
        payment_terms TEXT, quality_ppm REAL, single_source INTEGER, financial_rating TEXT)""",
    "materials": """CREATE TABLE materials (material_id TEXT PRIMARY KEY, description TEXT NOT NULL,
        material_type TEXT CHECK (material_type IN ('FERT','HALB','ROH')), uom TEXT REFERENCES uom(uom),
        procurement_type TEXT CHECK (procurement_type IN ('In-house','External')),
        lot_size_rule TEXT CHECK (lot_size_rule IN ('LFL','FIXED')), lot_size REAL,
        lead_time_days INTEGER, safety_stock REAL, unit_cost REAL, supplier_id TEXT, plant_id TEXT REFERENCES plants(plant_id))""",
    "bom": """CREATE TABLE bom (parent_id TEXT REFERENCES materials(material_id),
        component_id TEXT REFERENCES materials(material_id), quantity REAL NOT NULL, scrap_pct REAL, revision TEXT,
        PRIMARY KEY (parent_id, component_id))""",
    "work_centres": """CREATE TABLE work_centres (work_centre_id TEXT PRIMARY KEY, name TEXT, plant_id TEXT REFERENCES plants(plant_id),
        wc_group TEXT, machines INTEGER, shifts_per_day INTEGER, hours_per_shift REAL, efficiency REAL,
        availability REAL, speed_factor REAL, cost_rate_per_hr REAL)""",
    "routings": """CREATE TABLE routings (material_id TEXT REFERENCES materials(material_id), op_no INTEGER,
        operation TEXT, work_centre_id TEXT REFERENCES work_centres(work_centre_id), wc_group TEXT,
        setup_hrs REAL, run_min_per_unit REAL, PRIMARY KEY (material_id, op_no))""",
    "demand_history": """CREATE TABLE demand_history (month TEXT, material_id TEXT REFERENCES materials(material_id),
        demand REAL, PRIMARY KEY (month, material_id))""",
    "inventory": """CREATE TABLE inventory (material_id TEXT REFERENCES materials(material_id), plant_id TEXT,
        on_hand REAL, last_movement_date TEXT, PRIMARY KEY (material_id, plant_id))""",
    "scheduled_receipts": """CREATE TABLE scheduled_receipts (po_id TEXT PRIMARY KEY, material_id TEXT REFERENCES materials(material_id),
        supplier_id TEXT, quantity REAL, due_date TEXT)""",
    "supplier_deliveries": """CREATE TABLE supplier_deliveries (delivery_id TEXT PRIMARY KEY, supplier_id TEXT, material_id TEXT,
        order_date TEXT, promised_date TEXT, actual_date TEXT, qty_ordered REAL, qty_received REAL)""",
}
_ORDER = ["plants", "uom", "suppliers", "materials", "bom", "work_centres", "routings", "demand_history",
          "inventory", "scheduled_receipts", "supplier_deliveries"]


def connect(db_path: str | Path) -> sqlite3.Connection:
    p = Path(db_path)
    p.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(p)
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def _to_sql_ready(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    for c in out.columns:
        if pd.api.types.is_datetime64_any_dtype(out[c]):
            out[c] = out[c].dt.strftime("%Y-%m-%d")
        elif out[c].dtype == bool:
            out[c] = out[c].astype(int)
    return out


def init_master_schema(conn: sqlite3.Connection) -> None:
    """Drop and recreate master-data tables."""
    conn.execute("PRAGMA foreign_keys = OFF")
    for t in reversed(_ORDER):
        conn.execute(f"DROP TABLE IF EXISTS {t}")
    for t in _ORDER:
        conn.execute(SCHEMA_DDL[t])
    conn.execute("PRAGMA foreign_keys = ON")
    conn.commit()


def save_master(conn: sqlite3.Connection, data: dict[str, pd.DataFrame]) -> None:
    """Persist master/transaction input tables using the defined schema."""
    init_master_schema(conn)
    for t in _ORDER:
        cols = [r[1] for r in conn.execute(f"PRAGMA table_info({t})")]
        _to_sql_ready(data[t])[cols].to_sql(t, conn, if_exists="append", index=False)
    conn.commit()


def save_results(conn: sqlite3.Connection, tables: dict[str, pd.DataFrame]) -> None:
    """Persist result tables (replaced on every run)."""
    for name, df in tables.items():
        _to_sql_ready(df).to_sql(f"res_{name}", conn, if_exists="replace", index=False)
    conn.commit()


def read_table(conn: sqlite3.Connection, name: str) -> pd.DataFrame:
    return pd.read_sql_query(f"SELECT * FROM {name}", conn)


def list_tables(conn: sqlite3.Connection) -> list[str]:
    return [r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")]
