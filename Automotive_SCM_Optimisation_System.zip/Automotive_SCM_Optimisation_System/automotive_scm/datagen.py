"""Synthetic data generator.

Everything produced here is FICTIONAL: company-neutral products, suppliers,
plants and demand. No real company data is used.
"""
from __future__ import annotations

import math

import numpy as np
import pandas as pd

from . import bom as bomlib

PRODUCTS = ["GBX-100", "PMP-200"]

# (id, description, type, uom, procurement, lot_rule, lot_size, lead_time_days,
#  safety_stock, unit_cost, supplier_id, plant)
_MATERIALS = [
    ("GBX-100", "Gearbox Assembly", "FERT", "EA", "In-house", "LFL", 0, 3, 400, 310.00, "", "PLANT-A"),
    ("PMP-200", "Coolant Pump Assembly", "FERT", "EA", "In-house", "FIXED", 500, 3, 600, 96.00, "", "PLANT-B"),
    ("GBX-110", "Gear Train Subassembly", "HALB", "EA", "In-house", "LFL", 0, 2, 200, 118.00, "", "PLANT-A"),
    ("GBX-120", "Gearbox Housing Assembly", "HALB", "EA", "In-house", "LFL", 0, 3, 200, 52.00, "", "PLANT-A"),
    ("SHF-001", "Gearbox Input Shaft (machined)", "HALB", "EA", "In-house", "FIXED", 1000, 4, 300, 9.20, "", "PLANT-A"),
    ("PMP-210", "Pump Rotor Subassembly", "HALB", "EA", "In-house", "LFL", 0, 2, 300, 18.50, "", "PLANT-B"),
    ("PMP-220", "Pump Body Subassembly", "HALB", "EA", "In-house", "LFL", 0, 3, 300, 17.80, "", "PLANT-B"),
    ("SHF-002", "Pump Shaft (machined)", "HALB", "EA", "In-house", "FIXED", 1000, 4, 400, 4.60, "", "PLANT-B"),
    ("STL-001", "Alloy Steel Bar 42CrMo4", "ROH", "KG", "External", "FIXED", 10000, 21, 3000, 2.10, "S01", "PLANT-A"),
    ("GER-001", "Transmission Gear (helical)", "ROH", "EA", "External", "FIXED", 3000, 35, 3000, 14.50, "S02", "PLANT-A"),
    ("BRG-001", "Deep-Groove Bearing (gearbox)", "ROH", "EA", "External", "FIXED", 2000, 28, 2000, 3.20, "S03", "PLANT-A"),
    ("BRG-002", "Deep-Groove Bearing (pump)", "ROH", "EA", "External", "FIXED", 2500, 28, 2500, 2.40, "S03", "PLANT-B"),
    ("SEL-001", "Oil Seal (gearbox)", "ROH", "EA", "External", "LFL", 0, 14, 800, 0.90, "S04", "PLANT-A"),
    ("SEL-002", "Housing Gasket", "ROH", "EA", "External", "FIXED", 1000, 14, 300, 0.75, "S04", "PLANT-A"),
    ("SEL-003", "Pump Body O-Ring", "ROH", "EA", "External", "FIXED", 2000, 14, 800, 0.40, "S04", "PLANT-B"),
    ("SEL-004", "Mechanical Shaft Seal", "ROH", "EA", "External", "LFL", 0, 21, 500, 6.80, "S04", "PLANT-B"),
    ("ALC-001", "Aluminium Casting - Gearbox Housing", "ROH", "EA", "External", "FIXED", 1000, 42, 500, 38.00, "S05", "PLANT-A"),
    ("ALC-002", "Aluminium Casting - Pump Body", "ROH", "EA", "External", "FIXED", 1500, 38, 600, 11.00, "S05", "PLANT-B"),
    ("MTR-001", "Brushless Electric Motor 12V", "ROH", "EA", "External", "FIXED", 1000, 45, 600, 28.00, "S06", "PLANT-B"),
    ("FST-001", "Hex Bolt M10 (fastener)", "ROH", "EA", "External", "FIXED", 20000, 10, 6000, 0.12, "S07", "PLANT-A"),
    ("FST-002", "Flange Screw M6 (fastener)", "ROH", "EA", "External", "FIXED", 25000, 10, 8000, 0.06, "S07", "PLANT-A"),
    ("FST-003", "Stud M8 (fastener)", "ROH", "EA", "External", "FIXED", 10000, 10, 3000, 0.09, "S07", "PLANT-B"),
    ("IMP-001", "Pump Impeller", "ROH", "EA", "External", "FIXED", 3000, 30, 1500, 4.50, "S08", "PLANT-B"),
]
_MATERIAL_COLS = ["material_id", "description", "material_type", "uom", "procurement_type", "lot_size_rule",
                  "lot_size", "lead_time_days", "safety_stock", "unit_cost", "supplier_id", "plant_id"]

# parent, component, qty, scrap_pct
_BOM = [
    ("GBX-100", "GBX-110", 1, 0), ("GBX-100", "GBX-120", 1, 0),
    ("GBX-100", "FST-001", 12, 2), ("GBX-100", "SEL-001", 2, 1),
    ("GBX-110", "GER-001", 3, 0.5), ("GBX-110", "BRG-001", 2, 0), ("GBX-110", "SHF-001", 1, 0),
    ("GBX-120", "ALC-001", 1, 2), ("GBX-120", "SEL-002", 1, 0), ("GBX-120", "FST-002", 6, 2),
    ("SHF-001", "STL-001", 2.5, 3),
    ("PMP-200", "PMP-210", 1, 0), ("PMP-200", "PMP-220", 1, 0), ("PMP-200", "MTR-001", 1, 0),
    ("PMP-200", "FST-003", 4, 2), ("PMP-200", "SEL-004", 1, 0),
    ("PMP-210", "SHF-002", 1, 0), ("PMP-210", "BRG-002", 2, 0), ("PMP-210", "IMP-001", 1, 0),
    ("PMP-220", "ALC-002", 1, 2), ("PMP-220", "FST-002", 6, 2), ("PMP-220", "SEL-003", 2, 0),
    ("SHF-002", "STL-001", 1.2, 3),
]

_SUPPLIERS = [
    # id, name, country, payment_terms, quality_ppm, single_source, financial_rating, base_otd, mean_delay_days
    ("S01", "Northwind Alloys Ltd", "India", "Net 45", 350, 0, "A", 0.93, 2.0),
    ("S02", "Apex Gear Works", "India", "Net 60", 900, 1, "B", 0.84, 4.5),
    ("S03", "BlueRidge Bearings Co", "Germany", "Net 60", 250, 0, "A", 0.95, 1.5),
    ("S04", "Cobalt Seals & Gaskets", "Thailand", "Net 30", 400, 0, "A", 0.96, 1.5),
    ("S05", "Meridian Castings Pvt Ltd", "India", "Net 45", 1500, 1, "C", 0.76, 6.0),
    ("S06", "VoltDrive Motors Inc", "China", "Net 60", 800, 1, "B", 0.82, 5.0),
    ("S07", "FastLine Fasteners", "India", "Net 30", 200, 0, "A", 0.97, 1.0),
    ("S08", "Summit Impellers GmbH", "Germany", "Net 45", 600, 0, "B", 0.88, 3.0),
]
_SUPPLIER_COLS = ["supplier_id", "name", "country", "payment_terms", "quality_ppm", "single_source",
                  "financial_rating"]

_WORK_CENTRES = [
    # id, name, plant, group, machines, shifts, hrs/shift, efficiency, availability, speed_factor, rate
    ("WC-A-TURN1", "CNC Turning Cell 1 (new)", "PLANT-A", "TURNING", 1, 2, 8, 0.85, 0.92, 1.00, 48),
    ("WC-A-TURN2", "CNC Turning Cell 2 (older)", "PLANT-A", "TURNING", 1, 1, 8, 0.80, 0.88, 1.15, 40),
    ("WC-A-HEAT1", "Heat Treatment Furnace", "PLANT-A", "HEAT_TREAT", 1, 1, 8, 0.90, 0.90, 1.00, 55),
    ("WC-A-GRND1", "Cylindrical Grinder 1", "PLANT-A", "GRINDING", 1, 1, 8, 0.85, 0.92, 1.00, 45),
    ("WC-A-GRND2", "Cylindrical Grinder 2 (older)", "PLANT-A", "GRINDING", 1, 1, 8, 0.80, 0.88, 1.10, 38),
    ("WC-A-MILL1", "Machining Centre 1", "PLANT-A", "MILLING", 2, 2, 8, 0.82, 0.90, 1.00, 60),
    ("WC-A-MILL2", "Machining Centre 2 (older)", "PLANT-A", "MILLING", 1, 1, 8, 0.80, 0.88, 1.12, 50),
    ("WC-A-WASH1", "Parts Wash Station", "PLANT-A", "WASHING", 1, 1, 8, 0.90, 0.95, 1.00, 20),
    ("WC-A-SUBA1", "Gear Train Subassembly Cell", "PLANT-A", "SUBASSEMBLY", 1, 2, 8, 0.85, 0.95, 1.00, 30),
    ("WC-A-ASMB1", "Gearbox Final Assembly Line", "PLANT-A", "FINAL_ASSY", 1, 3, 8, 0.85, 0.95, 1.00, 70),
    ("WC-A-ASMB2", "Gearbox Flex Assembly Line (older)", "PLANT-A", "FINAL_ASSY", 1, 1, 8, 0.80, 0.90, 1.10, 55),
    ("WC-A-TEST1", "Gearbox End-of-Line Test Bench", "PLANT-A", "TESTING", 1, 1, 8, 0.90, 0.93, 1.00, 35),
    ("WC-A-TEST2", "Gearbox Test Bench 2 (older)", "PLANT-A", "TESTING", 1, 1, 8, 0.80, 0.90, 1.10, 30),
    ("WC-B-TURN1", "CNC Turning Cell B1", "PLANT-B", "TURNING", 1, 1, 8, 0.85, 0.92, 1.00, 46),
    ("WC-B-TURN2", "CNC Turning Cell B2 (older)", "PLANT-B", "TURNING", 1, 1, 8, 0.80, 0.88, 1.15, 38),
    ("WC-B-GRND1", "Cylindrical Grinder B1", "PLANT-B", "GRINDING", 1, 1, 8, 0.85, 0.92, 1.00, 44),
    ("WC-B-MILL1", "Machining Centre B1", "PLANT-B", "MILLING", 1, 2, 8, 0.82, 0.90, 1.00, 58),
    ("WC-B-MILL2", "Machining Centre B2 (older)", "PLANT-B", "MILLING", 1, 1, 8, 0.80, 0.88, 1.12, 48),
    ("WC-B-WASH1", "Parts Wash Station B", "PLANT-B", "WASHING", 1, 1, 8, 0.90, 0.95, 1.00, 20),
    ("WC-B-SUBA1", "Pump Rotor Subassembly Cell", "PLANT-B", "SUBASSEMBLY", 1, 2, 8, 0.85, 0.95, 1.00, 28),
    ("WC-B-ASMB1", "Pump Final Assembly Line", "PLANT-B", "FINAL_ASSY", 1, 3, 8, 0.85, 0.95, 1.00, 65),
    ("WC-B-ASMB2", "Pump Flex Assembly Line (older)", "PLANT-B", "FINAL_ASSY", 1, 1, 8, 0.80, 0.90, 1.10, 50),
    ("WC-B-TEST1", "Pump Leak-Test Bench", "PLANT-B", "TESTING", 1, 1, 8, 0.90, 0.93, 1.00, 32),
    ("WC-B-TEST2", "Pump Test Bench 2 (older)", "PLANT-B", "TESTING", 1, 1, 8, 0.80, 0.90, 1.10, 28),
]
_WC_COLS = ["work_centre_id", "name", "plant_id", "wc_group", "machines", "shifts_per_day", "hours_per_shift",
            "efficiency", "availability", "speed_factor", "cost_rate_per_hr"]

# material, op_no, operation, work_centre, group, setup_hrs, run_min_per_unit
_ROUTINGS = [
    ("SHF-001", 10, "CNC turning", "WC-A-TURN1", "TURNING", 1.5, 3.0),
    ("SHF-001", 20, "Heat treatment", "WC-A-HEAT1", "HEAT_TREAT", 1.0, 1.0),
    ("SHF-001", 30, "Cylindrical grinding", "WC-A-GRND1", "GRINDING", 1.0, 2.0),
    ("GBX-110", 10, "Gear train assembly", "WC-A-SUBA1", "SUBASSEMBLY", 1.0, 5.0),
    ("GBX-120", 10, "Housing machining", "WC-A-MILL1", "MILLING", 2.0, 6.0),
    ("GBX-120", 20, "Washing", "WC-A-WASH1", "WASHING", 0.5, 1.0),
    ("GBX-100", 10, "Final assembly", "WC-A-ASMB1", "FINAL_ASSY", 1.0, 12.0),
    ("GBX-100", 20, "End-of-line test", "WC-A-TEST1", "TESTING", 0.5, 4.0),
    ("SHF-002", 10, "CNC turning", "WC-B-TURN1", "TURNING", 1.5, 2.4),
    ("SHF-002", 20, "Cylindrical grinding", "WC-B-GRND1", "GRINDING", 1.0, 1.5),
    ("PMP-210", 10, "Rotor assembly", "WC-B-SUBA1", "SUBASSEMBLY", 1.0, 4.0),
    ("PMP-220", 10, "Body machining", "WC-B-MILL1", "MILLING", 2.0, 4.5),
    ("PMP-220", 20, "Washing", "WC-B-WASH1", "WASHING", 0.5, 0.8),
    ("PMP-200", 10, "Final assembly", "WC-B-ASMB1", "FINAL_ASSY", 1.0, 8.0),
    ("PMP-200", 20, "Leak test", "WC-B-TEST1", "TESTING", 0.5, 3.0),
]

_SEASON = {
    "GBX-100": [0.95, 0.98, 1.06, 1.08, 1.05, 1.00, 0.97, 0.92, 1.02, 1.10, 1.08, 0.92],
    "PMP-200": [0.88, 0.92, 1.00, 1.10, 1.18, 1.20, 1.15, 1.08, 1.00, 0.95, 0.90, 0.86],
}
_BASE = {"GBX-100": 1800, "PMP-200": 2600}
_MONTHLY_TREND = {"GBX-100": 0.008, "PMP-200": 0.006}


def make_materials() -> pd.DataFrame:
    return pd.DataFrame(_MATERIALS, columns=_MATERIAL_COLS)


def make_bom() -> pd.DataFrame:
    df = pd.DataFrame(_BOM, columns=["parent_id", "component_id", "quantity", "scrap_pct"])
    df["revision"] = "A"
    return df


def make_suppliers() -> pd.DataFrame:
    return pd.DataFrame([s[:7] for s in _SUPPLIERS], columns=_SUPPLIER_COLS)


def make_uom() -> pd.DataFrame:
    return pd.DataFrame([("EA", "Each", "count"), ("KG", "Kilogram", "mass"), ("M", "Metre", "length"),
                         ("L", "Litre", "volume")], columns=["uom", "description", "dimension"])


def make_plants() -> pd.DataFrame:
    return pd.DataFrame([("PLANT-A", "Alpha Gearbox Plant (fictional)", "Region North"),
                         ("PLANT-B", "Beta Pump Plant (fictional)", "Region West")],
                        columns=["plant_id", "name", "location"])


def make_work_centres() -> pd.DataFrame:
    return pd.DataFrame(_WORK_CENTRES, columns=_WC_COLS)


def make_routings() -> pd.DataFrame:
    return pd.DataFrame(_ROUTINGS, columns=["material_id", "op_no", "operation", "work_centre_id", "wc_group",
                                            "setup_hrs", "run_min_per_unit"])


def make_demand_history(rng: np.random.Generator, months: int = 24, end: str = "2025-12-01") -> pd.DataFrame:
    end_ts = pd.Timestamp(end)
    idx = pd.date_range(end=end_ts, periods=months, freq="MS")
    rows = []
    for prod in PRODUCTS:
        for i, m in enumerate(idx):
            trend = (1 + _MONTHLY_TREND[prod]) ** i
            seas = _SEASON[prod][m.month - 1]
            noise = rng.normal(1.0, 0.04)
            rows.append((m, prod, int(round(_BASE[prod] * trend * seas * noise))))
    return pd.DataFrame(rows, columns=["month", "material_id", "demand"])


def _avg_recent_demand(history: pd.DataFrame, n: int = 3) -> dict[str, float]:
    out = {}
    for prod, g in history.groupby("material_id"):
        out[prod] = float(g.sort_values("month")["demand"].tail(n).mean())
    return out


def make_inventory(rng: np.random.Generator, materials: pd.DataFrame, bom: pd.DataFrame,
                   history: pd.DataFrame, snapshot: pd.Timestamp) -> pd.DataFrame:
    monthly = bomlib.explode_demand(bom, _avg_recent_demand(history)).set_index("component_id")["gross_requirement"].to_dict()
    monthly.update(_avg_recent_demand(history))
    cover_override = {"MTR-001": 0.35, "ALC-001": 0.45, "GER-001": 0.55, "ALC-002": 0.5, "BRG-001": 0.7,
                      "IMP-001": 1.9, "FST-003": 2.8, "SEL-001": 2.6}
    rows = []
    for r in materials.itertuples():
        base = monthly.get(r.material_id, 1000.0)
        if r.material_type == "FERT":
            cover = rng.uniform(0.25, 0.4)
        elif r.material_type == "HALB":
            cover = rng.uniform(0.2, 0.5)
        else:
            cover = rng.uniform(0.6, 1.6)
        cover = cover_override.get(r.material_id, cover)
        qty = int(round(base * cover))
        last_move = snapshot - pd.Timedelta(days=int(rng.integers(3, 140)))
        rows.append((r.material_id, r.plant_id, qty, last_move))
    return pd.DataFrame(rows, columns=["material_id", "plant_id", "on_hand", "last_movement_date"])


def make_scheduled_receipts(rng: np.random.Generator, materials: pd.DataFrame, inventory: pd.DataFrame,
                            snapshot: pd.Timestamp) -> pd.DataFrame:
    rows = []
    po = 4500100
    for r in materials[materials["procurement_type"] == "External"].itertuples():
        if rng.random() < 0.35:
            continue  # no open PO
        n = int(rng.integers(1, 3))
        for _ in range(n):
            lot = r.lot_size if r.lot_size and r.lot_size > 0 else max(int(r.safety_stock * 2), 1000)
            qty = int(lot * rng.choice([1, 1, 2]))
            due = snapshot + pd.Timedelta(days=int(rng.integers(5, 50)))
            rows.append((f"PO-{po}", r.material_id, r.supplier_id, qty, due))
            po += 1
    return pd.DataFrame(rows, columns=["po_id", "material_id", "supplier_id", "quantity", "due_date"])


def make_supplier_deliveries(rng: np.random.Generator, materials: pd.DataFrame,
                             snapshot: pd.Timestamp) -> pd.DataFrame:
    rows = []
    n = 1
    for sid, _name, _c, _p, _q, _s, _f, otd, mean_delay in _SUPPLIERS:
        mats = materials[materials["supplier_id"] == sid]
        for _ in range(60):
            m = mats.iloc[int(rng.integers(0, len(mats)))]
            order_date = snapshot - pd.Timedelta(days=int(rng.integers(60, 400)))
            promised = order_date + pd.Timedelta(days=int(m["lead_time_days"]))
            if rng.random() < otd:
                delay = -int(rng.integers(0, 3))
            else:
                delay = max(1, int(round(rng.exponential(mean_delay * 1.8))))
            actual = promised + pd.Timedelta(days=delay)
            ordered = int(m["lot_size"]) if m["lot_size"] > 0 else int(m["safety_stock"] * 2)
            received = ordered if rng.random() > 0.08 else int(ordered * rng.uniform(0.85, 0.98))
            rows.append((f"DLV-{n:05d}", sid, m["material_id"], order_date, promised, actual, ordered, received))
            n += 1
    df = pd.DataFrame(rows, columns=["delivery_id", "supplier_id", "material_id", "order_date", "promised_date",
                                     "actual_date", "qty_ordered", "qty_received"])
    return df.sort_values("order_date").reset_index(drop=True)


def generate_all(seed: int = 42, history_months: int = 24, history_end: str = "2025-12-01") -> dict[str, pd.DataFrame]:
    """Generate the full synthetic raw dataset as {table_name: DataFrame}."""
    if history_months < 12:
        raise ValueError("history_months must be at least 12")
    rng = np.random.default_rng(seed)
    snapshot = pd.Timestamp(history_end) + pd.offsets.MonthBegin(1)
    materials = make_materials()
    bom = make_bom()
    bomlib.validate_bom(bom, materials["material_id"])
    history = make_demand_history(rng, history_months, history_end)
    inventory = make_inventory(rng, materials, bom, history, snapshot)
    return {
        "materials": materials,
        "uom": make_uom(),
        "plants": make_plants(),
        "bom": bom,
        "suppliers": make_suppliers(),
        "work_centres": make_work_centres(),
        "routings": make_routings(),
        "demand_history": history,
        "inventory": inventory,
        "scheduled_receipts": make_scheduled_receipts(rng, materials, inventory, snapshot),
        "supplier_deliveries": make_supplier_deliveries(rng, materials, snapshot),
    }


def write_raw_csvs(tables: dict[str, pd.DataFrame], out_dir) -> list:
    """Write each table to <out_dir>/<name>.csv with ISO dates."""
    from pathlib import Path
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    paths = []
    for name, df in tables.items():
        p = out / f"{name}.csv"
        df.to_csv(p, index=False, date_format="%Y-%m-%d")
        paths.append(p)
    return paths
