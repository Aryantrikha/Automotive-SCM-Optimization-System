# Data Dictionary

*All values are synthetic and fictional.* Raw files live in `data/raw/`; dates are ISO `YYYY-MM-DD`.

## materials.csv (23 rows)
| Column | Description |
|---|---|
| material_id | Key. e.g. `GBX-100` |
| description | Text |
| material_type | `FERT` finished product, `HALB` semi-finished, `ROH` raw / purchased |
| uom | Base unit of measure (`EA`, `KG`) - must exist in `uom.csv` |
| procurement_type | `In-house` (produced) or `External` (purchased) |
| lot_size_rule | `LFL` lot-for-lot or `FIXED` fixed lot |
| lot_size | Fixed lot quantity (0 for LFL) |
| lead_time_days | In-house production lead time or supplier lead time |
| safety_stock | Target minimum stock (base UoM) |
| unit_cost | Standard cost per base unit (synthetic currency) |
| supplier_id | Supplier for external materials (blank for in-house) |
| plant_id | Owning plant |

## uom.csv - `uom, description, dimension`
## plants.csv - `plant_id, name, location`

## bom.csv (23 rows)
| Column | Description |
|---|---|
| parent_id, component_id | Key pair; both must exist in materials |
| quantity | Component quantity per 1 parent (> 0) |
| scrap_pct | Scrap allowance in percent; effective qty = quantity x (1 + scrap/100) |
| revision | BOM revision label (informational) |

## suppliers.csv (8 rows)
`supplier_id, name, country, payment_terms, quality_ppm` (defective parts per million), `single_source` (1 = sole source for a
material), `financial_rating` (A best, C weakest).

## work_centres.csv (24 rows)
| Column | Description |
|---|---|
| work_centre_id, name, plant_id | Identification |
| wc_group | Capability group; work centres in the same group and plant are interchangeable |
| machines, shifts_per_day, hours_per_shift | Capacity structure |
| efficiency, availability | Fractions (0-1) |
| speed_factor | 1.0 = reference; 1.15 = needs 15 % more run time (older machine) |
| cost_rate_per_hr | Informational |

Monthly available hours = machines x shifts x hours/shift x working days x efficiency x availability.

## routings.csv (15 rows)
`material_id, op_no, operation, work_centre_id` (primary), `wc_group`, `setup_hrs` (per order),
`run_min_per_unit`. Required hours = setup + qty x run_min / 60.

## demand_history.csv (48 rows)
`month` (first of month), `material_id`, `demand` - 24 months for 2 products.

## inventory.csv - `material_id, plant_id, on_hand, last_movement_date` (snapshot at planning start)
## scheduled_receipts.csv - open purchase orders: `po_id, material_id, supplier_id, quantity, due_date`
## supplier_deliveries.csv (480 rows)
`delivery_id, supplier_id, material_id, order_date, promised_date, actual_date, qty_ordered, qty_received`.
On time = actual <= promised; in full = received >= ordered.

## Output tables (`outputs/` and `res_*` in SQLite)

| File | Key columns |
|---|---|
| demand_forecast | material_id, period_start, forecast_qty, method |
| mrp_grid | per material/period: opening_stock, gross_requirement, scheduled_receipts, net_requirement, planned_receipt, projected_stock, safety_stock, projected_stock_no_new_supply |
| mrp_planned_orders | planned_order_id, order_type (`Production Order` / `Purchase Requisition`), quantity, need_date, release_date, lead_time_days, past_due, days_late, supplier_id, value |
| shortage_alerts | material_id, alert_type, severity (Critical/High/Warning), shortage_qty, need_date, earliest_possible_date, days_late |
| production_plan | per FG/period: forecast_demand, opening_stock, planned_production, closing_stock |
| production_orders | order_id, planned_qty, start_date, due_date, status, components_available, short_components |
| capacity_utilisation_* | work_centre_id, period_start, required_hours, available_hours, utilisation, status, overload_hours |
| capacity_alerts | overloaded work-centre months (baseline) |
| capacity_assignments | order/operation to assigned work centre after optimisation |
| inventory_status | on_hand, reorder_point, days_of_cover, stock_value, age_days, status |
| supplier_risk | otd_rate, in_full_rate, pts_* components, risk_score, risk_class |
| replenishment_recommendations | action (EXPEDITE / Release now / Plan), supplier_risk, comment |
| execution_orders | status, actual_qty, actual_start, actual_end, qty_variance, delay_days |
| goods_movements | movement_type (GI / GR / GR-PO), material_id, signed quantity, reference |
| kpi_summary | KPI, Value |

## Formulas
* Reorder point = (monthly demand / 30) x lead time + safety stock.
* Days of cover = on-hand / daily demand.
* Turnover = annualised consumption value / current stock value.
* Utilisation = required hours / available hours; status OK (<= 85 %), Warning (<= 100 %), Overloaded (> 100 %).
* Supplier risk points: OTD gap max 35, delay severity 15, quality 10, single source 15, financial rating 15, lead time 10.
  Class: High >= 60, Medium >= 35, else Low (configurable).
