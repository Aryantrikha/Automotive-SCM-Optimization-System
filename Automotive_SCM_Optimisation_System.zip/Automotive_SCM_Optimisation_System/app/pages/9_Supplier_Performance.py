import plotly.express as px
import streamlit as st

import common as c
from automotive_scm import supplier

c.setup_page("Supplier Performance", "🚚")
res = c.header("Supplier Performance", "On-time delivery, risk classification, long-lead components and replenishment actions")
risk = res["supplier_risk"].copy()
target = res["config"]["thresholds"]["supplier_otd_target"]

m = st.columns(4)
m[0].metric("Suppliers", len(risk))
m[1].metric("High risk", int((risk["risk_class"] == "High").sum()))
m[2].metric("Below OTD target", int((risk["otd_rate"] < target).sum()), help=f"Target {target:.0%}")
m[3].metric("Overall OTD", f"{res['kpis']['supplier_otd_overall']:.0%}")

c1, c2 = st.columns(2)
with c1:
    fig = px.bar(risk.sort_values("otd_rate"), x="otd_rate", y="name", orientation="h", color="risk_class",
                 color_discrete_map=c.STATUS_COLOURS, title="On-time delivery rate by supplier", labels={"name": "", "otd_rate": "OTD"})
    fig.add_vline(x=target, line_dash="dash", annotation_text="target")
    fig.update_xaxes(tickformat=".0%", range=[0, 1])
    st.plotly_chart(c.style_fig(fig, 380))
with c2:
    comp = risk.melt(id_vars=["name"], value_vars=["pts_otd", "pts_delay", "pts_quality", "pts_single", "pts_fin", "pts_lt"],
                     var_name="component", value_name="points")
    comp["component"] = comp["component"].map({"pts_otd": "OTD gap", "pts_delay": "Delay severity", "pts_quality": "Quality",
                                               "pts_single": "Single source", "pts_fin": "Financial", "pts_lt": "Lead time"})
    fig = px.bar(comp, x="points", y="name", color="component", orientation="h", title="Risk score composition (max 100)",
                 labels={"name": ""})
    st.plotly_chart(c.style_fig(fig, 380))

tab1, tab2, tab3, tab4 = st.tabs(["Supplier scorecard", "OTD trend", "Critical long-lead components", "Replenishment recommendations"])
with tab1:
    cols = ["supplier_id", "name", "country", "otd_rate", "in_full_rate", "avg_actual_lead_time", "avg_delay_days_when_late",
            "quality_ppm", "single_source", "financial_rating", "risk_score", "risk_class"]
    st.dataframe(risk[cols].sort_values("risk_score", ascending=False).round(2), hide_index=True)
    st.caption("Risk score = OTD gap (35) + delay severity (15) + quality ppm (10) + single-source (15) + financial rating (15) "
               "+ lead-time exposure (10). Thresholds are configurable in config/settings.yaml.")
with tab2:
    tr = supplier.monthly_otd(res["data"]["supplier_deliveries"])
    tr = tr.merge(risk[["supplier_id", "name"]], on="supplier_id")
    sel = st.multiselect("Suppliers", sorted(tr["name"].unique()), default=sorted(tr["name"].unique()))
    fig = px.line(tr[tr["name"].isin(sel)], x="month", y="otd_rate", color="name", markers=True, title="Monthly OTD (by promised month)")
    fig.update_yaxes(tickformat=".0%", range=[0, 1.05])
    st.plotly_chart(c.style_fig(fig, 420))
with tab3:
    ll = res["long_lead"]
    st.caption(f"External materials with lead time of at least {res['config']['thresholds']['long_lead_time_days']} days.")
    st.dataframe(ll.round(2), hide_index=True)
with tab4:
    rec = res["replenishment"].copy()
    acts = st.multiselect("Action", ["EXPEDITE", "Release now", "Plan"], default=["EXPEDITE", "Release now", "Plan"])
    rec = rec[rec["action"].isin(acts)]
    for col in ("release_date", "need_date"):
        rec[col] = rec[col].dt.strftime("%d %b %Y")
    st.dataframe(rec.round(2), hide_index=True)
    c.download_button(res["replenishment"], "replenishment_recommendations.csv", "dl_rep")
