# SAP Concept Mapping

> **This project is an independent Python simulation. It is not SAP configuration, not an SAP implementation, and it
> does not connect to, extract from or reproduce any SAP system or any company's SAP setup.** The table below maps
> *generic, publicly documented planning concepts* to the equivalent idea in this code, for learning and
> interview-discussion purposes only. Real SAP behaviour is considerably richer.

| SAP concept (generic) | Purpose in SAP | Counterpart in this project | Difference / simplification |
|---|---|---|---|
| **SAP PP** (Production Planning) | Plan and execute manufacturing | The whole pipeline (forecast > MRP > orders > capacity > execution) | Single script pipeline, no transactions, authorisations or organisational structure |
| **Material Master** | One record per material with views (MRP, purchasing, costing...) | `materials.csv` / `materials` table: type, UoM, procurement type, lot size rule, lead time, safety stock, cost | Single flat table, no plant-specific views, no valuation classes |
| **BOM** | Structure of a product with quantities | `bom.csv`, `bom.py` (multi-level, scrap, circular check, low-level codes) | One revision, no alternatives, variants, effectivity dates |
| **Work Centres** | Resources with capacity and cost rates | `work_centres.csv`: shifts, efficiency, availability, speed | No capacity categories, formulas or scheduling calendars |
| **Routings** | Sequence of operations with standard times | `routings.csv`: setup + run time per operation, primary work centre | No task-list groups, no overlapping / transition times |
| **Demand Management** | Planned independent requirements | Forecast of finished products becomes independent demand | No strategy groups, no sales orders, no consumption of forecast |
| **MRP** | Net requirements, lot sizing, planned orders, exception messages | `mrp.py`: net calculation, LFL / fixed lot, lead-time scheduling, past-due and below-safety alerts | Monthly buckets, no planning time fence, no MRP areas, no procurement proposals conversion |
| **Production Orders** | Execution documents with status | `production.py`, `execution.py`: Created > Released > In Progress > Completed | Simplified lifecycle; no confirmations per operation, no costing |
| **Goods Issue / Goods Receipt** | Stock movements consuming components / receiving output | `execution.goods_issue`, `goods_receipt`; types `GI`, `GR`, `GR-PO` | Conceptually similar to issue to order and receipt from order; no movement-type configuration, batches, storage locations |
| **Inventory Management** | Stock levels, valuation, reorder | `inventory.py`: on-hand, safety stock, reorder point, standard-cost value, ageing | No valuation areas, price control, batch/serial stock |
| **PLM & Engineering Change Management** | Control product data changes | Only a `revision` column in the BOM; the BOM is validated on every run | **Not implemented.** No change numbers, effectivity, approval workflows - see limitations |

## Conceptual flow comparison

```
Planned independent requirement -> MRP run -> planned orders -> convert to production / purchase order
  -> release -> goods issue (components) -> confirmation -> goods receipt (output)
```
In this project the corresponding steps are: forecast -> `run_mrp` -> `create_production_orders` ->
status `Released` -> `goods_issue` -> `In Progress` -> `goods_receipt` -> `Completed`.

## Using this honestly in an interview

Say: "I built an independent simulation of the planning logic that SAP PP implements, so I could reason about
MRP, BOMs and capacity in code. It is not an SAP configuration, and I would still need to learn the real system's
customising and transactions." Do not claim hands-on SAP configuration experience based on this project.
