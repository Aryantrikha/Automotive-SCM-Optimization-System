# Interview Guide

*Independent, company-neutral portfolio project using synthetic data. Not an SAP implementation.*

## 60-second answer

"I built an Automotive Supply Chain and Production Planning system in Python for a fictional gearbox and coolant-pump
manufacturer. It forecasts demand from 24 months of synthetic history, explodes a three-level BOM, runs a time-phased MRP
with safety stock and lot sizing, and flags shortages where supplier lead times can't be met. It then converts the plan into
production orders, checks work-centre capacity and rebalances overloads, scores supplier risk, and simulates execution with
goods issue and receipt. Everything feeds a ten-page Streamlit dashboard with KPIs, and it's covered by 46 automated tests.
It's an independent simulation inspired by SAP PP concepts - not an SAP implementation - so I could understand the planning
logic end to end."

## Architecture explanation (30 seconds)
A UI-independent engine (`automotive_scm`: forecasting, BOM, MRP, inventory, production, capacity, supplier, execution, KPIs)
orchestrated by `pipeline.run_pipeline`. Configuration in YAML, validated CSV inputs, SQLite persistence, and a thin Streamlit
layer. Functions are pure and DataFrame-based, so each is unit-tested.

## Business-process explanation
Forecast -> independent demand -> MRP nets against stock, receipts and safety stock level by level -> planned purchase and
production orders with lead-time-offset dates -> capacity check -> execution -> KPIs. Alerts: lead-time violations (expedite),
below safety stock, capacity overload, high-risk suppliers.

## Technical explanation
* BOM: recursive explosion with scrap and cycle detection (DFS colouring); low-level codes via Kahn's topological ordering.
* MRP: process materials in low-level order so all dependent demand is known; per bucket
  `net = max(0, gross + SS - (stock + receipts))`, lot size, then release = need - lead time.
* Capacity: required hours = setup + qty x run/60; available = machines x shifts x hours x days x efficiency x availability.
  Optimiser slices each operation and sends slices to the least-utilised eligible work centre once the primary exceeds the warning level.
* Supplier risk: weighted 0-100 score from OTD gap, delay severity, quality, single-sourcing, financial rating, lead time.

## Limitations to volunteer
Synthetic data; monthly buckets; infinite-capacity MRP followed by a heuristic rebalance; simple forecasting; no ECM; simulated
execution; not SAP. See `limitations.md`.

## 25 likely questions and answers

1. **Why this project?** To learn how planning logic (forecast, BOM, MRP, capacity) fits together by implementing it, and to
   show analytics plus supply-chain reasoning.
2. **Is this SAP?** No. It is an independent Python simulation using generic concepts that SAP PP also implements. I have not
   configured SAP and I'd say so.
3. **Is any real company's data used?** No. Products, suppliers, plants and numbers are fictional and generated with a seed.
4. **What is MRP?** A procedure that turns demand into time-phased supply proposals by netting gross requirements against stock
   and receipts, applying lot sizes and offsetting by lead time.
5. **Gross vs net requirement?** Gross is total need; net is what remains after available stock, scheduled receipts and the
   safety-stock target.
6. **How do you handle multi-level BOMs?** Materials are processed in low-level-code order; a parent's planned order release
   creates dependent demand for each component at that date, scaled by quantity and scrap.
7. **How do you detect circular BOMs?** Depth-first search with white/grey/black colouring; a grey node reached again is a cycle.
   The cycle is reported and MRP refuses to run.
8. **Lot-for-lot vs fixed lot?** LFL orders exactly the net; fixed rounds up to a multiple of the lot, creating surplus that
   carries into later periods.
9. **What is a low-level code?** The deepest BOM level at which a material appears; it ensures a component is planned only after
   all its parents.
10. **How is safety stock handled?** MRP treats it as a target minimum: net requirement includes it. A toggle in the sidebar shows its effect.
11. **What does a "lead-time violation" mean?** The planned release date falls before the run date, so even ordering today the
    material can't arrive by the need date; it needs expediting.
12. **Which forecasting methods and why?** Moving average (baseline), seasonal naive (captures strong seasonality), simple
    exponential smoothing. A hold-out back-test compares MAE/MAPE. On the synthetic data seasonal naive had the lowest MAE for both products (the pump series is strongly seasonal); the 3-month hold-out is small, so treat that as indicative.
13. **How would you improve forecasting?** Holt-Winters or ARIMA/ML, hierarchical forecasts, promotions and events, forecast-bias
    tracking, rolling-origin cross-validation.
14. **How is capacity calculated?** Machines x shifts x hours x working days x efficiency x availability; load from routings.
15. **What does your optimisation do and why not OR-Tools?** A transparent greedy balancer across eligible work centres, with
    slower machines costing more hours. It's explainable and dependency-free; a MIP/CP-SAT model would be the next step.
16. **Does MRP consider capacity?** No - classic MRP is infinite-capacity. Capacity is checked afterwards, which mirrors common practice.
17. **How is supplier risk scored?** Weighted points: OTD gap 35, delay severity 15, quality 10, single source 15, financial 15,
    lead time 10; High >= 60, Medium >= 35. Weights are judgemental and configurable.
18. **What are critical long-lead items?** External materials with lead time at or above 35 days (castings, motors, gears); they need earlier ordering and buffers.
19. **How do goods issue and receipt work here?** Starting an order issues components (negative movements); completion receives
    confirmed output (planned x yield). Purchase receipts post as GR-PO.
20. **How do you validate data?** Required columns, unique keys, date parsing, referential integrity, positive quantities, valid lot rules, BOM cycles.
21. **How did you test it?** 46 pytest tests: arithmetic of forecasts, BOM scenarios, MRP netting/lot/lead-time cases, capacity formulas,
    optimiser behaviour, pipeline invariants.
22. **What KPIs matter most?** Forecast accuracy, inventory value/turnover, shortage count, OTD, capacity utilisation, order completion and plan attainment.
23. **How would this scale?** Move to a database-backed pipeline, weekly buckets, vectorised/partitioned MRP, scheduling jobs, API access.
24. **How would ECM fit in?** Add effectivity dates and change numbers to the BOM/routing, version the data, and run impact analysis on open orders. Not implemented today.
25. **Biggest weakness?** Synthetic data and simplified assumptions; no real-world validation. I'd calibrate against actual demand, lead-time variability and shop-floor data.

## Phrases to avoid
"I implemented SAP", "this reflects my company's process", "uses real production data".
