"""Configuration and raw-data loading with validation.

No absolute paths: everything is resolved relative to the project root.
"""
from __future__ import annotations

from pathlib import Path

import pandas as pd
import yaml

PROJECT_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_CONFIG = PROJECT_ROOT / "config" / "settings.yaml"

SYNTHETIC_LABEL = "SYNTHETIC DATA - fictional company, suppliers and plants. Not real company data."

# table -> (required columns, date columns, key columns)
SCHEMAS: dict[str, dict] = {
    "materials": dict(
        required=["material_id", "description", "material_type", "uom", "procurement_type", "lot_size_rule",
                  "lot_size", "lead_time_days", "safety_stock", "unit_cost", "supplier_id", "plant_id"],
        dates=[], key=["material_id"]),
    "uom": dict(required=["uom", "description", "dimension"], dates=[], key=["uom"]),
    "plants": dict(required=["plant_id", "name", "location"], dates=[], key=["plant_id"]),
    "bom": dict(required=["parent_id", "component_id", "quantity", "scrap_pct", "revision"], dates=[],
                key=["parent_id", "component_id"]),
    "suppliers": dict(required=["supplier_id", "name", "country", "payment_terms", "quality_ppm",
                                "single_source", "financial_rating"], dates=[], key=["supplier_id"]),
    "work_centres": dict(
        required=["work_centre_id", "name", "plant_id", "wc_group", "machines", "shifts_per_day",
                  "hours_per_shift", "efficiency", "availability", "speed_factor", "cost_rate_per_hr"],
        dates=[], key=["work_centre_id"]),
    "routings": dict(required=["material_id", "op_no", "operation", "work_centre_id", "wc_group", "setup_hrs",
                               "run_min_per_unit"], dates=[], key=["material_id", "op_no"]),
    "demand_history": dict(required=["month", "material_id", "demand"], dates=["month"],
                           key=["month", "material_id"]),
    "inventory": dict(required=["material_id", "plant_id", "on_hand", "last_movement_date"],
                      dates=["last_movement_date"], key=["material_id", "plant_id"]),
    "scheduled_receipts": dict(required=["po_id", "material_id", "supplier_id", "quantity", "due_date"],
                               dates=["due_date"], key=["po_id"]),
    "supplier_deliveries": dict(
        required=["delivery_id", "supplier_id", "material_id", "order_date", "promised_date", "actual_date",
                  "qty_ordered", "qty_received"],
        dates=["order_date", "promised_date", "actual_date"], key=["delivery_id"]),
}


class DataValidationError(ValueError):
    """Raised when input data fails validation."""


def load_config(path: str | Path | None = None) -> dict:
    """Load YAML configuration (default: config/settings.yaml) and sanity-check it."""
    p = Path(path) if path else DEFAULT_CONFIG
    if not p.is_absolute() and not p.exists():
        p = PROJECT_ROOT / p
    if not p.exists():
        raise FileNotFoundError(f"Config file not found: {p}")
    with open(p, "r", encoding="utf-8") as fh:
        cfg = yaml.safe_load(fh) or {}
    for section in ("paths", "planning", "forecasting", "thresholds"):
        if section not in cfg:
            raise DataValidationError(f"Config is missing section '{section}'")
    h = cfg["planning"].get("horizon_months")
    if not isinstance(h, int) or not 1 <= h <= 12:
        raise DataValidationError("planning.horizon_months must be an integer between 1 and 12")
    return cfg


def resolve_path(rel: str | Path) -> Path:
    """Resolve a config path relative to the project root."""
    p = Path(rel)
    return p if p.is_absolute() else PROJECT_ROOT / p


def validate_table(name: str, df: pd.DataFrame) -> pd.DataFrame:
    """Validate columns, nulls in keys and duplicate keys; parse dates."""
    spec = SCHEMAS[name]
    missing = [c for c in spec["required"] if c not in df.columns]
    if missing:
        raise DataValidationError(f"{name}: missing columns {missing}")
    df = df.copy()
    for c in spec["dates"]:
        df[c] = pd.to_datetime(df[c], errors="coerce")
        if df[c].isna().any():
            raise DataValidationError(f"{name}.{c}: contains invalid dates")
    if df[spec["key"]].isna().any().any():
        raise DataValidationError(f"{name}: null values in key columns {spec['key']}")
    if df.duplicated(spec["key"]).any():
        raise DataValidationError(f"{name}: duplicate keys on {spec['key']}")
    return df


def validate_dataset(d: dict[str, pd.DataFrame]) -> None:
    """Cross-table referential and range checks."""
    mats = set(d["materials"]["material_id"])
    m = d["materials"]
    if (m["lead_time_days"] < 0).any() or (m["safety_stock"] < 0).any() or (m["unit_cost"] < 0).any():
        raise DataValidationError("materials: lead time, safety stock and unit cost must be >= 0")
    if not set(m["lot_size_rule"]).issubset({"LFL", "FIXED"}):
        raise DataValidationError("materials.lot_size_rule must be LFL or FIXED")
    if ((m["lot_size_rule"] == "FIXED") & (m["lot_size"] <= 0)).any():
        raise DataValidationError("materials: FIXED lot size rule needs lot_size > 0")
    if not set(m["procurement_type"]).issubset({"In-house", "External"}):
        raise DataValidationError("materials.procurement_type must be In-house or External")
    if not set(m["uom"]).issubset(set(d["uom"]["uom"])):
        raise DataValidationError("materials reference an unknown unit of measure")
    ext = m[m["procurement_type"] == "External"]
    if not set(ext["supplier_id"]).issubset(set(d["suppliers"]["supplier_id"])):
        raise DataValidationError("External materials reference an unknown supplier")
    for tbl, col in (("inventory", "material_id"), ("routings", "material_id"), ("demand_history", "material_id"),
                     ("scheduled_receipts", "material_id"), ("supplier_deliveries", "material_id")):
        bad = set(d[tbl][col]) - mats
        if bad:
            raise DataValidationError(f"{tbl}: unknown materials {sorted(bad)}")
    if not set(d["routings"]["work_centre_id"]).issubset(set(d["work_centres"]["work_centre_id"])):
        raise DataValidationError("routings reference an unknown work centre")
    if (d["inventory"]["on_hand"] < 0).any():
        raise DataValidationError("inventory: negative on-hand quantities")
    if (d["demand_history"]["demand"] < 0).any():
        raise DataValidationError("demand_history: negative demand")
    from .bom import validate_bom
    validate_bom(d["bom"], mats)


def load_raw(raw_dir: str | Path | None = None, config: dict | None = None) -> dict[str, pd.DataFrame]:
    """Load and validate all raw CSV tables."""
    if raw_dir is None:
        cfg = config or load_config()
        raw_dir = resolve_path(cfg["paths"]["raw_data"])
    raw = Path(raw_dir)
    if not raw.exists():
        raise FileNotFoundError(f"Raw data folder not found: {raw}. Run: python scripts/generate_data.py")
    out = {}
    for name in SCHEMAS:
        f = raw / f"{name}.csv"
        if not f.exists():
            raise FileNotFoundError(f"Missing data file {f}. Run: python scripts/generate_data.py")
        out[name] = validate_table(name, pd.read_csv(f, keep_default_na=False, na_values=[""]))
        if name == "materials":
            out[name]["supplier_id"] = out[name]["supplier_id"].fillna("")
    validate_dataset(out)
    return out
