SYNTHETIC DATA - fictional company, suppliers and plants. Not real company data.
