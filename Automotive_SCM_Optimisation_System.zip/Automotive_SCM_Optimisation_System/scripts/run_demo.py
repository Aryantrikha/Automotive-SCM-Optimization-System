"""Run the full planning pipeline headlessly and write CSV outputs to outputs/.

Usage:  python scripts/run_demo.py [--horizon 6] [--method moving_average|seasonal_naive|exp_smoothing]
"""
import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from automotive_scm import datagen, kpis  # noqa: E402
from automotive_scm.data_loader import SYNTHETIC_LABEL, load_config, resolve_path  # noqa: E402
from automotive_scm.pipeline import run_pipeline, write_outputs  # noqa: E402


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--horizon", type=int, help="forecast/planning horizon in months (1-12)")
    ap.add_argument("--method", choices=["moving_average", "seasonal_naive", "exp_smoothing"])
    args = ap.parse_args()
    cfg = load_config()
    raw = resolve_path(cfg["paths"]["raw_data"])
    if not (raw / "materials.csv").exists():
        print("Raw data not found - generating synthetic data first ...")
        g = cfg.get("data_generation", {})
        datagen.write_raw_csvs(datagen.generate_all(g.get("seed", 42), g.get("history_months", 24),
                                                    g.get("history_end", "2025-12-01")), raw)
    overrides = {}
    if args.horizon:
        overrides["horizon_months"] = args.horizon
    if args.method:
        overrides["method"] = args.method
    results = run_pipeline(cfg, overrides=overrides)
    paths = write_outputs(results)
    print(SYNTHETIC_LABEL)
    print("\n=== KPI SUMMARY ===")
    print(kpis.kpi_table(results["kpis"]).to_string(index=False))
    print("\n=== TOP SHORTAGE ALERTS ===")
    print(results["mrp"].shortages.head(8)[["material_id", "alert_type", "severity", "shortage_qty", "days_late"]]
          .to_string(index=False))
    print("\nOutput files:")
    for p in paths:
        print("  ", p.relative_to(resolve_path(".")))
    print("   data/processed/scm.db (SQLite)")


if __name__ == "__main__":
    main()
