import pandas as pd
import plotly.express as px
import streamlit as st

import common as c
from automotive_scm import bom as bomlib

c.setup_page("BOM Explorer", "🔩")
res = c.header("BOM Explorer", "Multi-level bill of materials: recursive explosion, where-used and circular-reference check")
bom = res["data"]["bom"]
mats = res["data"]["materials"].set_index("material_id")

cycle = bomlib.find_circular_reference(bom)
if cycle:
    st.error("Circular BOM reference detected: " + " -> ".join(cycle))
else:
    st.success("BOM integrity check passed: no circular references.")

parents = sorted(bom["parent_id"].unique())
col1, col2 = st.columns([2, 1])
parent = col1.selectbox("Parent material", parents, format_func=lambda m: f"{m} - {mats.loc[m, 'description']}")
qty = col2.number_input("Quantity to build", min_value=1, value=100, step=10)
scrap = st.checkbox("Include scrap allowance", True)

ex = bomlib.explode_bom(bom, parent, qty, include_scrap=scrap)
ex["description"] = ex["component_id"].map(mats["description"])
ex["uom"] = ex["component_id"].map(mats["uom"])
ex["procurement"] = ex["component_id"].map(mats["procurement_type"])
ex["indented"] = ex.apply(lambda r: "    " * (r["level"] - 1) + r["component_id"], axis=1)

tab1, tab2, tab3, tab4 = st.tabs(["Exploded BOM", "Structure chart", "Total component requirement", "Where-used"])
with tab1:
    show = ex[["level", "indented", "description", "procurement", "qty_per_parent", "extended_qty", "uom"]].round(3)
    st.dataframe(show, hide_index=True)
with tab2:
    nodes = pd.concat([pd.DataFrame({"id": [parent], "parent": [""], "label": [parent], "level": [0]}),
                       pd.DataFrame({"id": ex["path"], "parent": ex["path"].str.rsplit(" > ", n=1).str[0],
                                     "label": ex["component_id"], "level": ex["level"]})])
    fig = px.treemap(nodes, ids="id", parents="parent", names="label", title=f"Structure of {parent}")
    fig.update_traces(root_color="lightgrey")
    st.plotly_chart(c.style_fig(fig, 520))
with tab3:
    tot = bomlib.explode_demand(bom, {parent: qty}, include_scrap=scrap)
    tot["description"] = tot["component_id"].map(mats["description"])
    tot["procurement"] = tot["component_id"].map(mats["procurement_type"])
    tot["gross_requirement"] = tot["gross_requirement"].round(2)
    st.dataframe(tot, hide_index=True)
    c.download_button(tot, f"gross_requirements_{parent}.csv", "dl_gross")
with tab4:
    allm = sorted(set(bom["component_id"]))
    comp = st.selectbox("Component", allm, format_func=lambda m: f"{m} - {mats.loc[m, 'description']}")
    wu = bomlib.where_used(bom, comp)
    st.dataframe(wu if len(wu) else pd.DataFrame({"info": ["Not used in any parent"]}), hide_index=True)
