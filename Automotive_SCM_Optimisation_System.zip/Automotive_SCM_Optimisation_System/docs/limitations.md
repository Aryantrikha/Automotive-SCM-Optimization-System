# Known Limitations

Documented honestly rather than hidden.

## Modelling
* **Synthetic data only.** Demand, costs, lead times and supplier performance are generated; conclusions have no real-world validity.
* **Monthly buckets.** No weekly/daily planning; need dates within a month are approximations (forecast due on the 15th).
* **Infinite-capacity MRP.** MRP ignores capacity; capacity is checked afterwards. The optimiser relieves overloads by
  splitting load across alternative work centres but does not re-time orders into other months.
* **Optimiser is a greedy heuristic**, not an exact/OR-Tools model. OR-Tools is not used and not required.
* **Forecasting is simple.** Moving average, seasonal naive and simple exponential smoothing only; no trend/seasonal
  smoothing (Holt-Winters), no ML, no prediction intervals. The back-test uses a single 3-month hold-out.
* **No safety-stock optimisation.** Safety stock is an input, not calculated from demand variability.
* **No planning time fence, no MRP areas, no alternative BOMs, no phantom assemblies, no co-products.**
* **Orders are not split by maximum lot size.** One planned order per material per month.
* **Scheduled receipts bucket by month** and are assumed on time in MRP; supplier unreliability enters only via risk scoring.
* **Execution is a simulation** with random delays and yields (fixed seed). Statuses are not driven by a real shop floor,
  and simulated issues may drive stock negative (this is displayed, not hidden).
* **Past-due planned orders** (release before run date) are flagged but not automatically re-planned.
* **Costing** uses a flat standard cost; no cost roll-up or variances.

## PLM / Engineering Change Management
Only a BOM `revision` field exists. Change orders, effectivity, approval workflow and change-impact analysis are **not implemented**.

## SAP
This is **not** SAP configuration, not an SAP implementation, and has no SAP connectivity. The mapping in `sap_mapping.md` is conceptual.

## Technical
* The dashboard recomputes the pipeline on control changes (cached per setting); fine for this data size, not for large data.
* Plotly/Streamlit rendering was not visually verified in the build environment (see `test_plan.md`).
* Interactive order simulation state lives in the browser session and resets on re-run or setting change.
* SQLite is a persistence/export target; the dashboard reads CSVs and recomputes rather than querying the database.
