import pandas as pd
import pytest

from automotive_scm import capacity as cap

PERIODS = [pd.Timestamp("2026-01-01"), pd.Timestamp("2026-02-01")]


def wcs():
    cols = ["work_centre_id", "name", "plant_id", "wc_group", "machines", "shifts_per_day", "hours_per_shift",
            "efficiency", "availability", "speed_factor", "cost_rate_per_hr"]
    return pd.DataFrame([
        ("W1", "Main", "P", "G", 1, 1, 10, 1.0, 1.0, 1.0, 10),
        ("W2", "Alt", "P", "G", 1, 1, 10, 1.0, 1.0, 1.0, 10),
        ("W3", "Other group", "P", "H", 1, 1, 10, 1.0, 1.0, 1.0, 10),
    ], columns=cols)


def routings():
    return pd.DataFrame([("M1", 10, "Op", "W1", "G", 2.0, 60.0)],
                        columns=["material_id", "op_no", "operation", "work_centre_id", "wc_group", "setup_hrs", "run_min_per_unit"])


def orders(qty):
    return pd.DataFrame([("O1", "M1", "P", qty, pd.Timestamp("2026-01-10"))],
                        columns=["order_id", "material_id", "plant_id", "planned_qty", "start_date"])


def test_available_hours_formula():
    a = cap.available_hours(wcs(), working_days=20).set_index("work_centre_id")
    assert a.loc["W1", "available_hours"] == 1 * 1 * 10 * 20


def test_required_hours_setup_plus_run():
    loads = cap.operation_loads(orders(50), routings())
    assert loads.iloc[0]["base_hours"] == pytest.approx(2.0 + 50 * 60 / 60)  # 52 h


def test_utilisation_and_status():
    loads, util = cap.baseline_capacity(orders(50), routings(), wcs(), PERIODS, working_days=20)
    u = util[(util.work_centre_id == "W1") & (util.period_start == PERIODS[0])].iloc[0]
    assert u.required_hours == pytest.approx(52)
    assert u.available_hours == 200
    assert u.utilisation == pytest.approx(0.26)
    assert u.status == "OK"


def test_over_capacity_alert_raised():
    loads, util = cap.baseline_capacity(orders(300), routings(), wcs(), PERIODS, working_days=20)
    alerts = cap.over_capacity_alerts(util)
    assert len(alerts) == 1
    assert alerts.iloc[0].work_centre_id == "W1"
    assert alerts.iloc[0].overload_hours == pytest.approx(302 - 200)


def test_warning_band():
    _, util = cap.baseline_capacity(orders(170), routings(), wcs(), PERIODS, working_days=20)  # 172/200 = 86 %
    assert util[util.work_centre_id == "W1"].iloc[0].status == "Warning"


def test_optimisation_relieves_overload_and_respects_groups():
    loads, util = cap.baseline_capacity(orders(300), routings(), wcs(), PERIODS, working_days=20)
    assign, util2 = cap.optimise_allocation(loads, wcs(), PERIODS, working_days=20)
    assert (util["status"] == "Overloaded").sum() == 1
    assert (util2["status"] == "Overloaded").sum() == 0
    assert set(assign["assigned_work_centre"]) <= {"W1", "W2"}   # never the other capability group
    # run time conserved when both centres have the same speed (plus one extra setup)
    assert assign["hours"].sum() == pytest.approx(300 + 2 + 2)


def test_optimisation_leaves_light_loads_on_primary():
    loads, _ = cap.baseline_capacity(orders(50), routings(), wcs(), PERIODS, working_days=20)
    assign, _ = cap.optimise_allocation(loads, wcs(), PERIODS, working_days=20)
    assert set(assign["assigned_work_centre"]) == {"W1"}


def test_empty_orders():
    loads = cap.operation_loads(orders(1).iloc[0:0], routings())
    assert loads.empty


def test_project_dataset_optimisation_never_worsens_peak():
    from automotive_scm.pipeline import run_pipeline
    from tests.test_mrp import _load
    r = run_pipeline(data=_load())
    assert r["capacity_util_optimised"]["utilisation"].max() <= r["capacity_util_baseline"]["utilisation"].max() + 1e-9
    assert (r["capacity_util_optimised"]["status"] == "Overloaded").sum() <= (r["capacity_util_baseline"]["status"] == "Overloaded").sum()
