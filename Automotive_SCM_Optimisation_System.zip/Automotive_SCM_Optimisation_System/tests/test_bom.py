import pandas as pd
import pytest

from automotive_scm import bom as b


def make_bom(rows):
    return pd.DataFrame(rows, columns=["parent_id", "component_id", "quantity", "scrap_pct"])


BOM = make_bom([("FG", "SUB", 2, 0), ("SUB", "RAW1", 3, 0), ("SUB", "RAW2", 1, 0), ("FG", "RAW1", 4, 0)])


def test_multilevel_explosion_quantities():
    e = b.explode_bom(BOM, "FG", 10)
    totals = e.groupby("component_id")["extended_qty"].sum()
    assert totals["SUB"] == 20
    assert totals["RAW1"] == 10 * (2 * 3 + 4)   # via SUB and direct
    assert totals["RAW2"] == 20
    assert e["level"].max() == 2


def test_explode_demand_aggregates_products():
    g = b.explode_demand(BOM, {"FG": 10}).set_index("component_id")["gross_requirement"]
    assert g["RAW1"] == 100 and g["RAW2"] == 20 and g["SUB"] == 20


def test_scrap_increases_requirement():
    bom = make_bom([("FG", "RAW", 10, 5)])
    assert b.explode_bom(bom, "FG", 1)["extended_qty"].iloc[0] == pytest.approx(10.5)
    assert b.explode_bom(bom, "FG", 1, include_scrap=False)["extended_qty"].iloc[0] == 10


def test_circular_reference_detected():
    bad = make_bom([("A", "B", 1, 0), ("B", "C", 1, 0), ("C", "A", 1, 0)])
    cycle = b.find_circular_reference(bad)
    assert cycle and cycle[0] == cycle[-1]
    with pytest.raises(b.CircularBOMError):
        b.validate_bom(bad)
    with pytest.raises(b.CircularBOMError):
        b.explode_bom(bad, "A")
    with pytest.raises(b.CircularBOMError):
        b.low_level_codes(bad)


def test_self_reference_detected():
    with pytest.raises(b.CircularBOMError):
        b.validate_bom(make_bom([("A", "A", 1, 0)]))


def test_acyclic_has_no_cycle():
    assert b.find_circular_reference(BOM) == []


def test_low_level_codes():
    llc = b.low_level_codes(BOM)
    assert llc == {"FG": 0, "SUB": 1, "RAW1": 2, "RAW2": 2}


def test_validation_errors():
    with pytest.raises(b.BOMError):
        b.validate_bom(make_bom([("A", "B", 0, 0)]))
    with pytest.raises(b.BOMError):
        b.validate_bom(make_bom([("A", "B", 1, 0), ("A", "B", 2, 0)]))
    with pytest.raises(b.BOMError):
        b.validate_bom(BOM, material_ids=["FG"])
    with pytest.raises(b.BOMError):
        b.build_graph(pd.DataFrame({"parent_id": ["A"]}))
    with pytest.raises(b.BOMError):
        b.explode_bom(BOM, "NOPE")


def test_where_used():
    w = b.where_used(BOM, "RAW2")
    assert set(w["used_in"]) == {"SUB", "FG"}


def test_project_bom_is_valid_and_multilevel():
    from automotive_scm import datagen
    bom = datagen.make_bom()
    b.validate_bom(bom, datagen.make_materials()["material_id"])
    e = b.explode_bom(bom, "GBX-100", 1)
    assert e["level"].max() == 3  # GBX-100 > GBX-110 > SHF-001 > STL-001
    steel = e[e["component_id"] == "STL-001"]["extended_qty"].iloc[0]
    assert steel == pytest.approx(2.5 * 1.03)
