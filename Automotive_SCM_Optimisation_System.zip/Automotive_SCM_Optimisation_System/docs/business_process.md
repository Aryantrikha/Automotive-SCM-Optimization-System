# Business Process

*All data is synthetic; the company is fictional.*

## 1. Business problem

A discrete manufacturer of gearboxes and coolant pumps must decide, every planning cycle:

* How many finished units to build each month (demand uncertainty, seasonality).
* Which components and raw materials to buy, how much and by when (supplier lead times of up to 45 days).
* Whether plants and work centres can actually deliver the plan (capacity).
* Which suppliers put the plan at risk and where stock is too low or too high.

Poor answers cause line stoppages (shortages), excess inventory (cash tied up), late deliveries and overtime.

## 2. Objectives

1. Convert forecast demand into a consistent plan across all BOM levels.
2. Highlight shortages and lead-time problems early, with supplier context.
3. Check feasibility against work-centre capacity and rebalance load.
4. Track execution (planned vs actual) and produce KPIs.
5. Demonstrate planning logic transparently in code, as a portfolio / learning project.

## 3. End-to-end process flow

```
Demand history  ->  Forecast (MA / seasonal naive / ES)
                          |
                 Independent demand (FG)
                          |
   BOM  ---------->  MRP netting by low-level code  <---- Inventory + scheduled receipts + safety stock
                          |
          +---------------+----------------+
          |                                |
 Planned purchase requisitions     Planned production orders
          |                                |
 Supplier risk / replenishment      Routing -> work-centre load
 recommendations                    -> utilisation / alerts -> load balancing
                                           |
                                  Execution simulation
                     (Created > Released > In Progress > Completed;
                      goods issue, goods receipt, delays)
                                           |
                                   KPI dashboard
```

## 4. Step descriptions

| # | Step | Module | Output |
|---|---|---|---|
| 1 | Load and validate master/transaction data | `data_loader.py` | Clean tables, errors on bad data |
| 2 | Forecast monthly demand per product | `forecasting.py` | `demand_forecast.csv` |
| 3 | Explode BOM, compute low-level codes, reject cycles | `bom.py` | Requirements per level |
| 4 | Run MRP (gross > net > lot size > release date) | `mrp.py` | `mrp_grid.csv`, `mrp_planned_orders.csv`, `shortage_alerts.csv` |
| 5 | Production plan and orders; component availability | `production.py` | `production_plan.csv`, `production_orders.csv` |
| 6 | Capacity check and optimisation | `capacity.py` | `capacity_*.csv` |
| 7 | Inventory status and valuation | `inventory.py` | `inventory_status.csv` |
| 8 | Supplier scoring and purchase recommendations | `supplier.py` | `supplier_risk.csv`, `replenishment_recommendations.csv` |
| 9 | Execution simulation | `execution.py` | `execution_orders.csv`, `goods_movements.csv` |
| 10 | KPIs | `kpis.py` | `kpi_summary.csv` |

## 5. Planning logic in plain words

* **Gross requirement** - what is needed in the month (forecast for products, parent orders x BOM quantity for components).
* **Net requirement** - gross plus the safety stock we want to keep, minus stock we will have (stock + open orders).
* **Lot sizing** - lot-for-lot orders exactly the net; fixed-lot rounds up to a multiple of the lot size.
* **Lead-time offset** - release date = need date - lead time. If that date is already in the past the order is
  **late** and appears as a lead-time violation alert.
* **Dependent demand** - an in-house order released on date D creates a requirement for its components on date D.

## 6. Planning assumptions

* Monthly buckets; demand due mid-month; a 22-day working month (configurable).
* One BOM version (revision A); no engineering change effectivity.
* Infinite-capacity MRP first, then a separate capacity check (as in classic planning).
* Planned orders are one per material per month (no splitting except in the capacity optimiser).
* Currency is a generic synthetic unit.
