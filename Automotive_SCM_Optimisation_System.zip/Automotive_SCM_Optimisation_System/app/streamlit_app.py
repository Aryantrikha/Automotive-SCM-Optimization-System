"""Executive Overview - home page of the dashboard.

Run:  streamlit run app/streamlit_app.py
"""
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

import common as c
from automotive_scm import kpis as kpimod

c.setup_page("Executive Overview")
res = c.header("Executive Overview", "Automotive SCM & Production Planning Optimisation System - GBX-100 Gearbox / PMP-200 Coolant Pump")
k = res["kpis"]

r1 = st.columns(4)
r1[0].metric("Forecast demand (units)", f"{k['forecast_demand_total']:,.0f}")
r1[1].metric("Planned production (FG units)", f"{k['planned_production_total']:,.0f}")
r1[2].metric("Inventory value", c.money(k["inventory_value"]), help="Standard cost, synthetic currency units")
r1[3].metric("Inventory turnover (x/yr)", f"{k['inventory_turnover']:.1f}")
r2 = st.columns(4)
r2[0].metric("Material shortage alerts", k["shortage_alerts"], delta=f"{k['critical_shortages']} critical",
             delta_color="inverse")
r2[1].metric("High-risk suppliers", k["high_risk_suppliers"])
r2[2].metric("Peak capacity utilisation", f"{k['peak_capacity_utilisation']:.0%}",
             delta=f"{k['overloaded_wc_periods']} overloaded WC-months", delta_color="inverse")
r2[3].metric("Supplier on-time delivery", f"{k['supplier_otd_overall']:.0%}",
             delta=f"target {k['supplier_otd_target']:.0%}", delta_color="off")
r3 = st.columns(4)
r3[0].metric("Orders completed (of due)", f"{k['order_completion_rate']:.0%}")
r3[1].metric("Completed on time", f"{k['orders_on_time_rate']:.0%}")
r3[2].metric("Plan attainment (qty)", f"{k['plan_attainment']:.1%}")
r3[3].metric("Delayed orders", k["delayed_orders"])

st.divider()
left, right = st.columns(2)
with left:
    plan = res["production_plan"].copy()
    plan["period"] = plan["period_start"].dt.strftime("%b %Y")
    long = plan.melt(id_vars=["material_id", "period", "period_start"], value_vars=["forecast_demand", "planned_production"],
                     var_name="measure", value_name="units")
    fig = px.bar(long, x="period", y="units", color="measure", barmode="group", facet_row="material_id",
                 title="Forecast demand vs planned production", labels={"period": ""})
    fig.update_yaxes(matches=None)
    st.plotly_chart(c.style_fig(fig, 460))
with right:
    util = res["capacity_util_baseline"].copy()
    util["period"] = util["period_start"].dt.strftime("%b %Y")
    piv = util.pivot(index="work_centre_id", columns="period", values="utilisation")
    piv = piv[[p.strftime("%b %Y") for p in res["periods"]]]
    fig = px.imshow(piv * 100, aspect="auto", color_continuous_scale="RdYlGn_r", zmin=0, zmax=130,
                    title="Capacity utilisation % (baseline)", labels=dict(color="%"))
    st.plotly_chart(c.style_fig(fig, 460))

a, b, d = st.columns(3)
with a:
    sh = res["mrp"].shortages
    if len(sh):
        cnt = sh.groupby(["severity"]).size().reset_index(name="alerts")
        fig = px.bar(cnt, x="severity", y="alerts", color="severity", color_discrete_map=c.STATUS_COLOURS,
                     title="Shortage alerts by severity")
    else:
        fig = go.Figure().update_layout(title="No shortage alerts")
    st.plotly_chart(c.style_fig(fig, 320))
with b:
    risk = res["supplier_risk"].sort_values("risk_score")
    fig = px.bar(risk, x="risk_score", y="name", orientation="h", color="risk_class",
                 color_discrete_map=c.STATUS_COLOURS, title="Supplier risk score", labels={"name": ""})
    st.plotly_chart(c.style_fig(fig, 320))
with d:
    ex = res["execution_orders"].groupby("status").size().reindex(["Created", "Released", "In Progress", "Completed"]).fillna(0).reset_index(name="orders")
    fig = px.pie(ex, names="status", values="orders", hole=0.5, color="status", color_discrete_map=c.STATUS_COLOURS,
                 title=f"Production order status (as of {res['as_of_date']:%d %b %Y})")
    st.plotly_chart(c.style_fig(fig, 320))

with st.expander("Full KPI table"):
    st.dataframe(kpimod.kpi_table(k), hide_index=True)
