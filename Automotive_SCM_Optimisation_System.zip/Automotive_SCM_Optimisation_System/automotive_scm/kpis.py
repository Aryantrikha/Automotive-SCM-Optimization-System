"""KPI calculations for the executive dashboard."""
from __future__ import annotations

import pandas as pd

from . import inventory as invlib


def compute_kpis(results: dict) -> dict:
    """Compute headline KPIs from the pipeline results dictionary."""
    fc = results["forecast"]
    plan = results["production_plan"]
    inv = results["inventory_status"]
    short = results["mrp"].shortages
    risk = results["supplier_risk"]
    util = results["capacity_util_baseline"]
    util_opt = results["capacity_util_optimised"]
    orders = results["execution_orders"]
    perf = results["supplier_perf"]
    completed = orders[orders["status"] == "Completed"]
    started = orders[orders["status"].isin(["In Progress", "Completed"])]
    due_by_now = orders[orders["due_date"] <= results["as_of_date"]]
    on_time_completed = completed[completed["delay_days"] == 0]
    deliveries = results["data"]["supplier_deliveries"]
    return {
        "forecast_demand_total": float(fc["forecast_qty"].sum()),
        "planned_production_total": float(plan["planned_production"].sum()),
        "inventory_value": float(inv["stock_value"].sum()),
        "inventory_turnover": invlib.inventory_turnover(inv),
        "materials_below_safety": int((inv["status"].isin(["Below safety stock", "Stockout"])).sum()),
        "shortage_alerts": int(len(short)),
        "critical_shortages": int((short["severity"] == "Critical").sum()) if len(short) else 0,
        "high_risk_suppliers": int((risk["risk_class"] == "High").sum()),
        "avg_capacity_utilisation": float(util["utilisation"].mean()),
        "peak_capacity_utilisation": float(util["utilisation"].max()),
        "overloaded_wc_periods": int((util["status"] == "Overloaded").sum()),
        "overloaded_wc_periods_optimised": int((util_opt["status"] == "Overloaded").sum()),
        "orders_total": int(len(orders)),
        "orders_completed": int(len(completed)),
        "order_completion_rate": float(len(completed) / len(due_by_now)) if len(due_by_now) else 0.0,
        "orders_in_progress": int((orders["status"] == "In Progress").sum()),
        "orders_on_time_rate": float(len(on_time_completed) / len(completed)) if len(completed) else 0.0,
        "delayed_orders": int((started["delay_days"] > 0).sum()),
        "plan_attainment": float(completed["actual_qty"].sum() / completed["planned_qty"].sum())
        if len(completed) and completed["planned_qty"].sum() else 0.0,
        "supplier_otd_overall": float((deliveries["actual_date"] <= deliveries["promised_date"]).mean()),
        "supplier_otd_target": results["config"]["thresholds"]["supplier_otd_target"],
        "suppliers_below_otd_target": int((perf["otd_rate"] < results["config"]["thresholds"]["supplier_otd_target"]).sum()),
    }


def kpi_table(kpis: dict) -> pd.DataFrame:
    """Human-readable KPI table."""
    labels = [
        ("forecast_demand_total", "Forecast demand (units, horizon)", "{:,.0f}"),
        ("planned_production_total", "Planned production - finished goods (units)", "{:,.0f}"),
        ("inventory_value", "Inventory value", "{:,.0f}"),
        ("inventory_turnover", "Inventory turnover (x / year)", "{:.1f}"),
        ("shortage_alerts", "Material shortage alerts", "{:,.0f}"),
        ("critical_shortages", "  of which Critical", "{:,.0f}"),
        ("high_risk_suppliers", "High-risk suppliers", "{:,.0f}"),
        ("avg_capacity_utilisation", "Average capacity utilisation", "{:.0%}"),
        ("peak_capacity_utilisation", "Peak capacity utilisation", "{:.0%}"),
        ("overloaded_wc_periods", "Overloaded work-centre months (baseline)", "{:,.0f}"),
        ("overloaded_wc_periods_optimised", "Overloaded work-centre months (optimised)", "{:,.0f}"),
        ("order_completion_rate", "Production orders completed (of those due)", "{:.0%}"),
        ("orders_on_time_rate", "Completed orders on time", "{:.0%}"),
        ("plan_attainment", "Planned vs actual quantity (completed orders)", "{:.1%}"),
        ("supplier_otd_overall", "Supplier on-time delivery (overall)", "{:.0%}"),
    ]
    return pd.DataFrame([(name, fmt.format(kpis[key])) for key, name, fmt in labels], columns=["KPI", "Value"])
