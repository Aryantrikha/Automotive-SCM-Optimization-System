import streamlit as st

import common as c

c.setup_page("Master Data", "🗂️")
res = c.header("Master Data", "Material master, suppliers, work centres, routings and units of measure (all synthetic)")
d = res["data"]

tabs = st.tabs(["Materials", "Suppliers", "Work centres", "Routings", "Units of measure", "Plants"])
with tabs[0]:
    m = d["materials"]
    c1, c2, c3 = st.columns(3)
    types = c1.multiselect("Material type", sorted(m["material_type"].unique()), default=sorted(m["material_type"].unique()))
    proc = c2.multiselect("Procurement", sorted(m["procurement_type"].unique()), default=sorted(m["procurement_type"].unique()))
    text = c3.text_input("Search id / description")
    f = m[m["material_type"].isin(types) & m["procurement_type"].isin(proc)]
    if text:
        f = f[f["material_id"].str.contains(text, case=False) | f["description"].str.contains(text, case=False)]
    st.caption("FERT = finished product, HALB = semi-finished, ROH = raw / purchased material. "
               "Lot rule: LFL = lot-for-lot, FIXED = fixed lot size.")
    st.dataframe(f, hide_index=True)
    c.download_button(f, "materials.csv", "dl_mat")
with tabs[1]:
    st.dataframe(d["suppliers"], hide_index=True)
with tabs[2]:
    wc = res["data"]["work_centres"]
    plant = st.selectbox("Plant", ["All"] + sorted(wc["plant_id"].unique()))
    st.dataframe(wc if plant == "All" else wc[wc["plant_id"] == plant], hide_index=True)
with tabs[3]:
    r = d["routings"]
    mat = st.selectbox("Material", ["All"] + sorted(r["material_id"].unique()))
    st.dataframe(r if mat == "All" else r[r["material_id"] == mat], hide_index=True)
with tabs[4]:
    st.dataframe(d["uom"], hide_index=True)
with tabs[5]:
    st.dataframe(d["plants"], hide_index=True)
