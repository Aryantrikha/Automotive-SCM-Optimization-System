import pandas as pd
import plotly.express as px
import streamlit as st

import common as c

c.setup_page("Production Planning", "🏗️")
res = c.header("Production Planning", "Planned production from forecast demand, BOM and inventory; planned production orders")
plan = res["production_plan"].copy()
plan["period"] = plan["period_start"].dt.strftime("%b %Y")

st.subheader("Finished-goods production plan")
fig = px.bar(plan, x="period", y=["forecast_demand", "planned_production"], barmode="group", facet_col="material_id",
             labels={"value": "Units", "period": "", "variable": ""})
fig.update_yaxes(matches=None)
st.plotly_chart(c.style_fig(fig, 380))
st.dataframe(plan.drop(columns="period_start").round(0), hide_index=True)

st.subheader("Planned production orders")
o = res["production_orders"].copy()
f1, f2, f3 = st.columns(3)
plants = f1.multiselect("Plant", sorted(o["plant_id"].unique()), default=sorted(o["plant_id"].unique()))
mats = f2.multiselect("Material", sorted(o["material_id"].unique()))
only_short = f3.checkbox("Only orders with component shortages", False)
f = o[o["plant_id"].isin(plants)]
if mats:
    f = f[f["material_id"].isin(mats)]
if only_short:
    f = f[~f["components_available"]]
st.dataframe(f.assign(start_date=f["start_date"].dt.strftime("%d %b %Y"), due_date=f["due_date"].dt.strftime("%d %b %Y")),
             hide_index=True)
c.download_button(o, "production_orders.csv", "dl_prd")
st.caption("'components_available' = FALSE means a direct component is not covered by on-hand stock, scheduled receipts "
           "or planned receipts by the order start date (after reserving earlier orders).")

if len(f):
    g = f.copy()
    g["start"] = g["start_date"]
    g["finish"] = g["due_date"] + pd.Timedelta(hours=18)
    fig = px.timeline(g, x_start="start", x_end="finish", y="material_id", color="plant_id",
                      title="Production order schedule (planned start to due date)")
    fig.update_yaxes(autorange="reversed")
    st.plotly_chart(c.style_fig(fig, 420))
