"""Inventory management: status, reorder points, valuation, ageing, turnover."""
from __future__ import annotations

import numpy as np
import pandas as pd

AGEING_BINS = [-1, 30, 60, 90, 10**6]
AGEING_LABELS = ["0-30 days", "31-60 days", "61-90 days", "90+ days"]


def monthly_demand_from_mrp(grid: pd.DataFrame, horizon: int) -> pd.Series:
    """Average monthly gross requirement per material over the planning horizon."""
    return grid.groupby("material_id")["gross_requirement"].sum() / max(horizon, 1)


def inventory_status(materials: pd.DataFrame, inventory: pd.DataFrame, receipts: pd.DataFrame,
                     monthly_demand: pd.Series, snapshot_date, excess_days: int = 90) -> pd.DataFrame:
    """One row per material with stock, safety stock, reorder point, value, cover and status.

    reorder point = daily demand * lead time + safety stock.
    """
    snap = pd.Timestamp(snapshot_date)
    stock = inventory.groupby("material_id").agg(on_hand=("on_hand", "sum"),
                                                 last_movement_date=("last_movement_date", "max"))
    sched = receipts.groupby("material_id")["quantity"].sum().rename("scheduled_receipts")
    df = materials.set_index("material_id").join(stock).join(sched)
    df["on_hand"] = df["on_hand"].fillna(0.0)
    df["scheduled_receipts"] = df["scheduled_receipts"].fillna(0.0)
    df["monthly_demand"] = monthly_demand.reindex(df.index).fillna(0.0)
    df["daily_demand"] = df["monthly_demand"] / 30.0
    df["reorder_point"] = (df["daily_demand"] * df["lead_time_days"] + df["safety_stock"]).round(0)
    df["stock_value"] = df["on_hand"] * df["unit_cost"]
    df["days_of_cover"] = np.where(df["daily_demand"] > 0, df["on_hand"] / df["daily_demand"].replace(0, np.nan), np.inf)
    df["age_days"] = (snap - df["last_movement_date"]).dt.days

    def status(r):
        if r["on_hand"] <= 0:
            return "Stockout"
        if r["on_hand"] < r["safety_stock"]:
            return "Below safety stock"
        if r["on_hand"] < r["reorder_point"]:
            return "Reorder"
        if r["days_of_cover"] > excess_days and r["monthly_demand"] > 0:
            return "Excess"
        return "OK"

    df["status"] = df.apply(status, axis=1)
    cols = ["description", "material_type", "uom", "plant_id", "on_hand", "scheduled_receipts", "safety_stock",
            "reorder_point", "monthly_demand", "days_of_cover", "unit_cost", "stock_value", "lead_time_days",
            "supplier_id", "age_days", "status"]
    return df[cols].reset_index()


def inventory_valuation(status: pd.DataFrame) -> pd.DataFrame:
    """Stock value by material type (standard-cost valuation)."""
    g = status.groupby("material_type").agg(materials=("material_id", "count"), stock_value=("stock_value", "sum"))
    g["share_pct"] = g["stock_value"] / g["stock_value"].sum() * 100 if g["stock_value"].sum() else 0.0
    return g.reset_index()


def ageing_profile(status: pd.DataFrame) -> pd.DataFrame:
    """Stock value per ageing bucket (days since last movement)."""
    b = pd.cut(status["age_days"].fillna(0), bins=AGEING_BINS, labels=AGEING_LABELS)
    out = status.assign(bucket=b).groupby("bucket", observed=False)["stock_value"].sum().reset_index()
    out.columns = ["ageing_bucket", "stock_value"]
    return out


def inventory_turnover(status: pd.DataFrame) -> float:
    """Annualised turnover = annual consumption value / current stock value."""
    consumption = float((status["monthly_demand"] * 12 * status["unit_cost"]).sum())
    value = float(status["stock_value"].sum())
    return consumption / value if value > 0 else 0.0
