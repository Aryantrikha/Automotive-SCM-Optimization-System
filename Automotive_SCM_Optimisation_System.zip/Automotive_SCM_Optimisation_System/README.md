# Automotive SCM & Production Planning Optimisation System

An independent, company-neutral **Python simulation** of automotive supply chain and production planning:
demand forecasting, multi-level BOM explosion, MRP, inventory, production orders, capacity planning,
supplier risk and production execution, with a 10-page Streamlit dashboard.

> **All data is synthetic.** The company, products, suppliers, plants and numbers are fictional. No confidential
> data, code, branding or processes of any real company are used. The project is *inspired by* SAP PP concepts but is
> **not** an SAP implementation or configuration (see `docs/sap_mapping.md`).

## Business scenario

A fictional component manufacturer builds two products in two fictional plants:

| Product | Description | Plant |
|---|---|---|
| GBX-100 | Gearbox Assembly (3 BOM levels: gearbox > gear train / housing > shaft > steel bar) | Alpha (PLANT-A) |
| PMP-200 | Coolant Pump Assembly (3 BOM levels incl. electric motor) | Beta (PLANT-B) |

23 materials (alloy steel, transmission gears, bearings, seals, aluminium castings, electric motors, fasteners,
impellers), 8 fictional suppliers, 24 work centres, 15 routing operations and 24 months of demand history.

## What it does

| Module | File | Highlights |
|---|---|---|
| Data & config | `data_loader.py`, `datagen.py`, `database.py` | CSV validation, referential checks, SQLite persistence |
| Forecasting | `forecasting.py` | Moving average, seasonal naive, exponential smoothing, hold-out back-test, configurable horizon (1-12 months) |
| BOM | `bom.py` | Recursive explosion, scrap, circular-reference detection, low-level codes, where-used |
| MRP | `mrp.py` | Time-phased netting, safety stock, lot-for-lot / fixed lot, lead-time offsetting, shortage alerts |
| Inventory | `inventory.py` | Reorder point, valuation, days of cover, ageing, turnover |
| Production | `production.py` | Production plan, planned orders with start/due dates, component availability check |
| Capacity | `capacity.py` | Required vs available hours, utilisation, over-capacity alerts, greedy load-balancing optimisation |
| Supplier | `supplier.py` | OTD, in-full, risk score and class, long-lead items, replenishment actions |
| Execution | `execution.py` | Created > Released > In Progress > Completed, planned vs actual, goods issue / receipt |
| KPIs | `kpis.py`, `pipeline.py` | End-to-end pipeline and KPI set |

## Install and run (Windows, PowerShell or cmd)

Requires Python 3.10+ (tested logic on 3.13).

```bat
cd Automotive_SCM_Optimisation_System
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python scripts\generate_data.py
python scripts\run_demo.py
python -m pytest -q
streamlit run app\streamlit_app.py
```

Shortcut: double-click `setup_windows.bat` once, then `run_dashboard.bat`.
On macOS/Linux use `source .venv/bin/activate` and forward slashes.

`scripts/generate_data.py` regenerates `data/raw/*.csv` (seeded, reproducible). `scripts/run_demo.py` runs the whole
pipeline headlessly, prints KPIs and writes 16 CSVs to `outputs/` plus `data/processed/scm.db`. Options:
`python scripts\run_demo.py --horizon 9 --method seasonal_naive`.

## Using the dashboard

Pages appear in the left navigation. The **sidebar planning controls** (horizon, forecast method, MA window, alpha,
safety stock on/off) apply to every page and re-run the pipeline.

1. **Executive Overview** - KPI tiles, forecast vs production, capacity heatmap, shortages, supplier risk, order status.
2. **Demand Forecasting** - history vs forecast per product, forecast table, method back-test.
3. **Master Data** - filter/search materials, suppliers, work centres, routings, UoM.
4. **BOM Explorer** - explode any assembly for any quantity, structure treemap, total requirements, where-used.
5. **MRP Planning** - shortage alerts, planned orders (filters, CSV export), per-material MRP grid chart.
6. **Inventory** - valuation, ageing, status (stockout / below safety / reorder / excess), scheduled receipts.
7. **Production Planning** - plan by period, production orders, component availability, Gantt.
8. **Capacity Planning** - utilisation heatmap (baseline vs optimised), alerts, optimisation comparison.
9. **Supplier Performance** - OTD vs target, risk composition, trend, long-lead items, replenishment actions.
10. **Production Execution** - status, planned vs actual, delays, goods movements, and a *Simulate next step* button.

## Key planning assumptions

* Monthly time buckets. Forecast demand is due on the 15th of each month; planned release = need date - lead time.
* Lead-time violations (release date before the run start) are flagged as **expedite** shortage alerts.
* Netting: `net = gross + safety stock - (projected stock + scheduled receipts)`; lot sizing then rounds up.
* Capacity = machines x shifts x hours x working days x efficiency x availability. Orders load the month of their start.
* Supplier risk score (0-100) combines OTD gap, delay severity, quality ppm, single-source, financial rating and lead time.

Full details: `docs/`.

## Folder structure

```
config/settings.yaml      all thresholds, horizon, paths (relative)
automotive_scm/           planning engine (no UI dependencies)
app/                      Streamlit dashboard (streamlit_app.py + pages/)
data/raw/                 synthetic input CSVs      data/processed/  SQLite database
outputs/                  sample pipeline outputs   docs/            documentation
scripts/                  generate_data.py, run_demo.py
tests/                    pytest suite
```

## Tests

```bat
python -m pytest -q
```

46 tests cover forecasting, BOM (including circular references), MRP (netting, lot sizing, safety stock, lead-time offset,
multi-level flow), capacity, execution and whole-pipeline invariants. See `docs/test_plan.md`.

## Known limitations

Read `docs/limitations.md`. In short: monthly buckets, finite-capacity is not enforced by MRP, simple forecasting,
synthetic data, no real SAP connectivity, and no OR-Tools model (a transparent greedy optimiser is used instead).
