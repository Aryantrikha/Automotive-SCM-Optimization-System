import pandas as pd
import plotly.express as px
import streamlit as st

import common as c
from automotive_scm import execution

c.setup_page("Production Execution", "✅")
res = c.header("Production Execution", "Order status, planned vs actual quantity, goods issue / receipt (simulation)")
as_of = res["as_of_date"]
st.caption(f"Simulation date: {as_of:%d %b %Y}. Statuses, delays and yields are randomly generated (fixed seed).")

# --- interactive state (reset whenever the planning inputs change) ---------------------------------
sig = (len(res["execution_orders"]), float(res["execution_orders"]["planned_qty"].sum()), str(as_of))
if st.session_state.get("exec_sig") != sig:
    st.session_state["exec_sig"] = sig
    st.session_state["exec_orders"] = res["execution_orders"].copy()
    st.session_state["exec_moves"] = res["goods_movements"].copy()
orders = st.session_state["exec_orders"]
moves = st.session_state["exec_moves"]

m = st.columns(5)
done = orders[orders["status"] == "Completed"]
m[0].metric("Orders", len(orders))
m[1].metric("Completed", len(done))
m[2].metric("In progress", int((orders["status"] == "In Progress").sum()))
m[3].metric("Delayed", int(((orders["status"].isin(["In Progress", "Completed"])) & (orders["delay_days"] > 0)).sum()))
att = done["actual_qty"].sum() / done["planned_qty"].sum() if len(done) and done["planned_qty"].sum() else 0
m[4].metric("Plan attainment", f"{att:.1%}")

tab1, tab2, tab3, tab4 = st.tabs(["Order status", "Planned vs actual", "Goods movements & stock", "Simulate next step"])
with tab1:
    sf = st.multiselect("Status", execution.STATUSES, default=execution.STATUSES)
    f = orders[orders["status"].isin(sf)].copy()
    for col in ("start_date", "due_date", "actual_start", "actual_end"):
        f[col] = pd.to_datetime(f[col]).dt.strftime("%d %b %Y")
    st.dataframe(f[["order_id", "material_id", "description", "status", "planned_qty", "actual_qty", "start_date", "due_date",
                    "actual_start", "actual_end", "delay_days", "components_available"]], hide_index=True)
    summ = execution.execution_summary(orders)
    st.plotly_chart(c.style_fig(px.bar(summ, x="status", y="orders", color="status", color_discrete_map=c.STATUS_COLOURS,
                                       title="Orders by status"), 320))
with tab2:
    g = orders[orders["status"].isin(["In Progress", "Completed"])].copy()
    if g.empty:
        st.info("No orders started yet.")
    else:
        long = g.melt(id_vars=["order_id", "material_id", "status"], value_vars=["planned_qty", "actual_qty"],
                      var_name="measure", value_name="units")
        fig = px.bar(long, x="order_id", y="units", color="measure", barmode="group", hover_data=["material_id", "status"],
                     title="Planned vs actual (confirmed) quantity")
        st.plotly_chart(c.style_fig(fig, 420))
        late = g[g["delay_days"] > 0][["order_id", "material_id", "status", "due_date", "actual_end", "delay_days"]]
        st.subheader("Delayed orders")
        st.dataframe(late.assign(due_date=late["due_date"].dt.strftime("%d %b %Y"),
                                 actual_end=pd.to_datetime(late["actual_end"]).dt.strftime("%d %b %Y")), hide_index=True)
with tab3:
    st.caption("GI = goods issue (component consumption), GR = goods receipt of production output, GR-PO = receipt of purchased material.")
    types = st.multiselect("Movement type", sorted(moves["movement_type"].unique()), default=sorted(moves["movement_type"].unique()))
    mv = moves[moves["movement_type"].isin(types)].copy()
    mv["posting_date"] = pd.to_datetime(mv["posting_date"]).dt.strftime("%d %b %Y")
    st.dataframe(mv, hide_index=True)
    after = execution.apply_movements(res["data"]["inventory"], moves)
    st.subheader("Stock after movements")
    st.caption("A negative closing stock means issues exceeded available stock (supply did not arrive in time).")
    st.dataframe(after.round(1), hide_index=True)
    neg = int(after["negative_stock"].sum())
    (st.warning if neg else st.success)(f"{neg} material(s) with negative stock after simulated movements.")
with tab4:
    open_orders = orders[orders["status"] != "Completed"]
    if open_orders.empty:
        st.success("All orders completed.")
    else:
        pick = st.selectbox("Order", open_orders["order_id"],
                            format_func=lambda o: f"{o} - {open_orders.set_index('order_id').loc[o, 'material_id']} "
                                                  f"({open_orders.set_index('order_id').loc[o, 'status']})")
        nxt = execution.next_status(open_orders.set_index("order_id").loc[pick, "status"])
        st.write(f"Advance **{pick}** to **{nxt}** on {as_of:%d %b %Y}.")
        if st.button(f"Advance to {nxt}"):
            st.session_state["exec_orders"], st.session_state["exec_moves"] = execution.advance_order(
                orders, moves, pick, res["data"]["bom"], as_of, res["config"].get("execution", {}).get("yield_mean", 0.985))
            st.rerun()
    if st.button("Reset simulation"):
        st.session_state.pop("exec_sig", None)
        st.rerun()
