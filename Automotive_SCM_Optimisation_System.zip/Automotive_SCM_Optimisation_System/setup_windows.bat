@echo off
REM One-time setup on Windows: creates a virtual environment, installs packages, generates data, runs tests.
cd /d "%~dp0"
python -m venv .venv || goto :error
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
pip install -r requirements.txt || goto :error
python scripts\generate_data.py || goto :error
python -m pytest -q || goto :error
echo.
echo Setup complete. Start the dashboard with run_dashboard.bat
goto :eof
:error
echo Setup failed - see the messages above.
exit /b 1
