"""Production planning: planned production plan and planned production orders."""
from __future__ import annotations

import pandas as pd

from . import bom as bomlib

ORDER_COLS = ["order_id", "material_id", "description", "plant_id", "planned_qty", "uom", "start_date",
              "due_date", "status", "past_due", "components_available", "short_components"]


def production_plan(grid: pd.DataFrame, forecast: pd.DataFrame, products: list[str]) -> pd.DataFrame:
    """Per finished product and period: forecast, opening stock, planned production, closing stock."""
    g = grid[grid["material_id"].isin(products)].copy()
    f = forecast.rename(columns={"forecast_qty": "forecast_demand"})[["material_id", "period_start", "forecast_demand"]]
    out = g.merge(f, on=["material_id", "period_start"], how="left")
    out = out.rename(columns={"planned_receipt": "planned_production", "projected_stock": "closing_stock"})
    return out[["material_id", "period_start", "forecast_demand", "opening_stock", "scheduled_receipts",
                "planned_production", "closing_stock", "safety_stock"]].reset_index(drop=True)


def create_production_orders(planned_orders: pd.DataFrame, start_date) -> pd.DataFrame:
    """Convert MRP in-house planned orders into production orders (status 'Created')."""
    start = pd.Timestamp(start_date)
    po = planned_orders[planned_orders["order_type"] == "Production Order"].copy()
    if po.empty:
        return pd.DataFrame(columns=ORDER_COLS)
    po = po.sort_values(["release_date", "material_id"]).reset_index(drop=True)
    po["order_id"] = [f"PRD-{1000 + i}" for i in range(len(po))]
    po["start_date"] = po["release_date"].where(po["release_date"] >= start, start)
    po["due_date"] = po["need_date"]
    po["planned_qty"] = po["quantity"]
    po["status"] = "Created"
    po["components_available"] = True
    po["short_components"] = ""
    return po[ORDER_COLS].copy()


def check_component_availability(orders: pd.DataFrame, bom: pd.DataFrame, inventory: pd.DataFrame,
                                 receipts: pd.DataFrame, planned_orders: pd.DataFrame) -> pd.DataFrame:
    """Chronological availability check of direct components for each production order.

    Supply for a component = on-hand + scheduled receipts + MRP planned receipts that
    arrive on or before the order start date, less quantity already reserved by earlier orders.
    """
    graph = bomlib.build_graph(bom)
    on_hand = inventory.groupby("material_id")["on_hand"].sum().to_dict()
    events: dict[str, list[tuple[pd.Timestamp, float]]] = {}
    for r in receipts.itertuples():
        events.setdefault(r.material_id, []).append((pd.Timestamp(r.due_date), float(r.quantity)))
    for r in planned_orders.itertuples():
        events.setdefault(r.material_id, []).append((pd.Timestamp(r.need_date), float(r.quantity)))
    reserved: dict[str, float] = {}
    out = orders.copy()
    avail_flags, short_lists = [], []
    for o in out.sort_values("start_date").itertuples():
        short = []
        for child, eff, _ in graph.get(o.material_id, []):
            need = o.planned_qty * eff
            supply = on_hand.get(child, 0.0) + sum(q for d, q in events.get(child, []) if d <= o.start_date)
            free = supply - reserved.get(child, 0.0)
            reserved[child] = reserved.get(child, 0.0) + need
            if free + 1e-9 < need:
                short.append(child)
        avail_flags.append((o.Index, not short))
        short_lists.append((o.Index, ", ".join(short)))
    for idx, ok in avail_flags:
        out.loc[idx, "components_available"] = ok
    for idx, s in short_lists:
        out.loc[idx, "short_components"] = s
    return out
