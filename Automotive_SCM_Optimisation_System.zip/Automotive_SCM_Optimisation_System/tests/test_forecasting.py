import numpy as np
import pandas as pd
import pytest

from automotive_scm import forecasting as fc


def test_moving_average_first_value_is_window_mean():
    out = fc.moving_average_forecast([10, 20, 30, 40], horizon=2, window=3)
    assert out[0] == pytest.approx(30.0)
    assert out[1] == pytest.approx((20 + 30 + 40 + 30) / 4 if False else (30 + 40 + 30) / 3)


def test_moving_average_constant_series():
    assert np.allclose(fc.moving_average_forecast([5] * 12, 4, 3), 5)


def test_horizon_is_configurable():
    for h in (1, 6, 12):
        assert len(fc.moving_average_forecast(range(1, 25), h)) == h
        assert len(fc.exp_smoothing_forecast(range(1, 25), h)) == h
        assert len(fc.seasonal_naive_forecast(range(1, 25), h)) == h


def test_seasonal_naive_repeats_last_season():
    hist = list(range(1, 25))  # 24 months
    out = fc.seasonal_naive_forecast(hist, 14, 12)
    assert list(out[:12]) == hist[-12:]
    assert out[12] == hist[-12]


def test_exp_smoothing_alpha_one_equals_last_value():
    assert fc.exp_smoothing_forecast([1, 2, 3, 9], 3, alpha=1.0).tolist() == [9, 9, 9]


@pytest.mark.parametrize("bad", [dict(values=[]), dict(values=[1, -2, 3]), dict(values=[1, np.nan, 3])])
def test_invalid_series_rejected(bad):
    with pytest.raises(ValueError):
        fc.moving_average_forecast(bad["values"], 2, 1)


def test_invalid_parameters_rejected():
    with pytest.raises(ValueError):
        fc.moving_average_forecast([1, 2, 3], 0)
    with pytest.raises(ValueError):
        fc.moving_average_forecast([1, 2], 2, window=5)
    with pytest.raises(ValueError):
        fc.exp_smoothing_forecast([1, 2, 3], 2, alpha=0)
    with pytest.raises(ValueError):
        fc.forecast_series([1, 2, 3], "magic", 2)
    with pytest.raises(ValueError):
        fc.seasonal_naive_forecast([1, 2, 3], 2, 12)


def _history():
    months = pd.date_range("2024-01-01", periods=24, freq="MS")
    rows = [(m, p, 100 + i * (1 if p == "A" else 2)) for p in ("A", "B") for i, m in enumerate(months)]
    return pd.DataFrame(rows, columns=["month", "material_id", "demand"])


def test_forecast_demand_dates_and_shape():
    out = fc.forecast_demand(_history(), "moving_average", 6)
    assert len(out) == 12
    assert out["period_start"].min() == pd.Timestamp("2026-01-01")
    assert out["period_start"].max() == pd.Timestamp("2026-06-01")
    assert (out["forecast_qty"] >= 0).all()


def test_forecast_demand_detects_gap_in_history():
    h = _history()
    h = h[h["month"] != pd.Timestamp("2024-06-01")]
    with pytest.raises(ValueError, match="missing months"):
        fc.forecast_demand(h, "moving_average", 3)


def test_historical_vs_forecast_combines_both():
    h = _history()
    f = fc.forecast_demand(h, "exp_smoothing", 3)
    combo = fc.historical_vs_forecast(h, f)
    assert set(combo["kind"]) == {"History", "Forecast"}
    assert len(combo) == len(h) + len(f)


def test_evaluate_methods_returns_all_methods():
    res = fc.evaluate_methods(list(range(100, 130)), test_months=3)
    assert set(res["method"]) == set(fc.METHODS)
    assert res["MAE"].notna().all()
