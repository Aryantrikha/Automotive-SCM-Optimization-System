# Software Architecture

## Layers

```
┌────────────────────────────  Streamlit UI (app/)  ────────────────────────────┐
│ streamlit_app.py (Executive Overview) + pages/2..10   common.py (controls, cache)
└───────────────────────────────────────┬────────────────────────────────────────┘
                                        │ run_pipeline(overrides)
┌───────────────────────────────────────▼────────────────────────────────────────┐
│ automotive_scm/pipeline.py  - orchestrates the modules, returns one results dict │
├─────────────┬───────────┬──────┬────────┬───────────┬─────────┬──────────┬──────┤
│ forecasting │   bom     │ mrp  │ inven- │ production│ capacity│ supplier │ exec │ kpis
│             │           │      │ tory   │           │         │          │ ution│
└─────────────┴───────────┴──────┴────────┴───────────┴─────────┴──────────┴──────┘
┌────────────────────────────────────────────────────────────────────────────────┐
│ data_loader.py (config, CSV validation)   database.py (SQLite)   datagen.py      │
└────────────────────────────────────────────────────────────────────────────────┘
 config/settings.yaml          data/raw/*.csv          data/processed/scm.db    outputs/*.csv
```

## Design principles

* **UI-independent engine.** `automotive_scm` imports only pandas/numpy/yaml/sqlite3, so it is unit-testable and
  runnable from scripts. The dashboard is a thin presentation layer.
* **Pure functions over DataFrames.** Each module takes tables and returns tables; no hidden global state.
* **Config-driven.** Horizon, forecast method, thresholds and paths live in `config/settings.yaml`. Paths are relative
  to the project root (`PROJECT_ROOT`), so no absolute paths.
* **Fail loudly on bad data.** Validation raises `DataValidationError`, `BOMError`, `CircularBOMError` or `ValueError`
  with explicit messages; the dashboard shows these as friendly errors.
* **Optional dependencies stay optional.** No OR-Tools dependency; capacity optimisation is a greedy heuristic.

## Module responsibilities and data flow

1. `data_loader.load_raw` reads and validates 11 CSV tables.
2. `forecasting.forecast_demand` -> forecast table (month after last history month onward).
3. `mrp.run_mrp` processes materials by low-level code. Parents' planned orders push dependent demand to children at their
   release date. Returns grid, planned orders and shortage alerts.
4. `production.create_production_orders` turns in-house planned orders into production orders; `check_component_availability`
   reserves components chronologically.
5. `capacity.operation_loads` joins orders with routings; `utilisation_table` computes load vs capacity;
   `optimise_allocation` rebalances to alternative work centres.
6. `execution.simulate_execution` assigns statuses as of a date, posts goods issue/receipt; `advance_order` supports
   the dashboard's step simulation.
7. `supplier` and `inventory` provide risk and stock analytics; `kpis.compute_kpis` summarises.
8. `pipeline.write_outputs` writes CSVs and persists everything to SQLite.

## Database schema (SQLite, `data/processed/scm.db`)

Master/input tables are created from DDL in `database.py` with primary keys, foreign keys and CHECK constraints:
`plants, uom, suppliers, materials, bom, work_centres, routings, demand_history, inventory, scheduled_receipts,
supplier_deliveries`. Result tables are stored as `res_<name>` (one per output CSV) and replaced on each run.
Column definitions are in `data_dictionary.md`.

## Error handling

| Situation | Behaviour |
|---|---|
| Missing CSV | `FileNotFoundError` with hint to run `generate_data.py` |
| Missing column / duplicate key / bad date | `DataValidationError` |
| Unknown material, supplier, work centre, UoM | `DataValidationError` |
| Circular BOM | `CircularBOMError` showing the cycle |
| Forecast history with missing months | `ValueError` |
| Invalid horizon / alpha / window | `ValueError` |
| Planning start not following history | `ValueError` |

## Extensibility

Add a forecasting method in `forecasting.py` and register it in `forecast_series`; add a lot-size rule in
`mrp.apply_lot_size`; replace the greedy optimiser with a solver model behind the same `optimise_allocation` signature.
