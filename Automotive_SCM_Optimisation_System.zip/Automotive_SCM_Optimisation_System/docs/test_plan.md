# Test Plan

## Scope
Unit and integration tests with pytest (`python -m pytest -q`). Current result: **46 passed**.

| File | Area | What is verified |
|---|---|---|
| `tests/test_forecasting.py` | Forecasting | MA arithmetic, constant series, horizon 1-12, seasonal-naive repeats last season, ES alpha=1, invalid inputs, missing-month detection, history/forecast merge, back-test output |
| `tests/test_bom.py` | BOM | Multi-level explosion quantities, scrap, aggregated demand, circular and self-references, low-level codes, validation errors, where-used, project BOM depth and steel quantity |
| `tests/test_mrp.py` | MRP + execution | Lot-for-lot and fixed lots, netting against stock and scheduled receipts, safety stock on/off, surplus carry-over, lead-time offset and past-due flag, below-safety alert, 3-level dependent demand, circular BOM stops MRP, input validation, whole-pipeline stock invariant, order status flow with goods issue/receipt |
| `tests/test_capacity.py` | Capacity | Available-hours formula, setup + run hours, utilisation and status bands, over-capacity alerts, optimiser relieves overload / keeps capability groups / leaves light loads alone, whole-pipeline optimiser never worsens peak |

## Manual / end-to-end checks performed
1. `python scripts/generate_data.py` creates 11 CSVs.
2. `python scripts/run_demo.py` runs the full pipeline, prints KPIs and writes 16 CSVs plus SQLite.
3. Smoke execution of all 10 dashboard pages (see limitation below).

## Not covered
* Visual rendering of Plotly charts and the Streamlit UI were **not** exercised in the build environment (packages
  unavailable there). Pages were executed against stand-in modules to catch data/pandas errors only.
  Run `streamlit run app/streamlit_app.py` and click through every page after installing requirements.
* No performance testing (dataset is small by design).

## How to run
```bat
python -m pytest -q            :: all tests
python -m pytest tests\test_mrp.py -v
```
