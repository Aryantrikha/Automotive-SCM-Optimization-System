"""Shared helpers for the Streamlit dashboard pages."""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import pandas as pd  # noqa: E402
import plotly.express as px  # noqa: E402
import streamlit as st  # noqa: E402

from automotive_scm import datagen  # noqa: E402
from automotive_scm.data_loader import SYNTHETIC_LABEL, load_config, load_raw, resolve_path  # noqa: E402
from automotive_scm.pipeline import run_pipeline  # noqa: E402

PALETTE = ["#1f6feb", "#e8710a", "#188038", "#a142f4", "#d93025", "#00897b", "#7f6000", "#5f6368"]
STATUS_COLOURS = {"OK": "#188038", "Warning": "#f9ab00", "Overloaded": "#d93025",
                  "Critical": "#d93025", "High": "#e8710a", "Low": "#188038", "Medium": "#f9ab00",
                  "Created": "#9aa0a6", "Released": "#1f6feb", "In Progress": "#f9ab00", "Completed": "#188038"}


def setup_page(title: str, icon: str = "🏭") -> None:
    st.set_page_config(page_title=f"{title} | Automotive SCM", page_icon=icon, layout="wide")
    st.markdown("""<style>
      .block-container {padding-top: 1.6rem;}
      [data-testid="stMetricValue"] {font-size: 1.6rem;}
      .syn-banner {background:#fff4e5;border-left:4px solid #e8710a;padding:6px 12px;border-radius:4px;
                   font-size:0.85rem;color:#5f370e;margin-bottom:0.8rem;}
    </style>""", unsafe_allow_html=True)


def _ensure_raw_data() -> None:
    cfg = load_config()
    raw = resolve_path(cfg["paths"]["raw_data"])
    if not (raw / "materials.csv").exists():
        g = cfg.get("data_generation", {})
        datagen.write_raw_csvs(datagen.generate_all(g.get("seed", 42), g.get("history_months", 24),
                                                    g.get("history_end", "2025-12-01")), raw)


@st.cache_data(show_spinner="Running planning pipeline ...")
def _cached_run(horizon: int, method: str, ma_window: int, alpha: float, safety: bool) -> dict:
    _ensure_raw_data()
    return run_pipeline(overrides={"horizon_months": horizon, "method": method, "ma_window": ma_window,
                                   "alpha": alpha, "use_safety_stock": safety})


def sidebar_and_results() -> dict:
    """Render planning controls in the sidebar and return pipeline results."""
    cfg = load_config()
    f = cfg["forecasting"]
    st.sidebar.title("Planning controls")
    horizon = st.sidebar.slider("Forecast / planning horizon (months)", 1, 12, int(cfg["planning"]["horizon_months"]),
                                key="ctl_horizon")
    methods = ["moving_average", "seasonal_naive", "exp_smoothing"]
    method = st.sidebar.selectbox("Forecast method", methods, index=methods.index(f["method"]), key="ctl_method")
    ma_window = st.sidebar.slider("Moving-average window", 2, 6, int(f.get("ma_window", 3)), key="ctl_ma",
                                  disabled=method != "moving_average")
    alpha = st.sidebar.slider("Smoothing alpha", 0.05, 1.0, float(f.get("alpha", 0.4)), 0.05, key="ctl_alpha",
                              disabled=method != "exp_smoothing")
    safety = st.sidebar.checkbox("Maintain safety stock in MRP", True, key="ctl_ss")
    st.sidebar.caption(SYNTHETIC_LABEL)
    try:
        return _cached_run(horizon, method, ma_window, alpha, safety)
    except Exception as exc:  # show a friendly error rather than a stack trace
        st.error(f"Could not run the planning pipeline: {exc}")
        st.stop()


def header(title: str, subtitle: str = "") -> dict:
    """Standard page header; returns pipeline results."""
    res = sidebar_and_results()
    st.title(title)
    if subtitle:
        st.caption(subtitle)
    st.markdown(f'<div class="syn-banner">⚠ {SYNTHETIC_LABEL} Independent Python simulation - not an SAP '
                f'implementation.</div>', unsafe_allow_html=True)
    return res


def fmt_period(df: pd.DataFrame, col: str = "period_start") -> pd.DataFrame:
    out = df.copy()
    if col in out.columns:
        out[col] = pd.to_datetime(out[col]).dt.strftime("%b %Y")
    return out


def style_fig(fig, height: int = 380):
    fig.update_layout(height=height, margin=dict(l=10, r=10, t=50, b=10), legend_title_text="",
                      colorway=PALETTE, plot_bgcolor="rgba(0,0,0,0)")
    return fig


def download_button(df: pd.DataFrame, name: str, key: str) -> None:
    st.download_button("Download CSV", df.to_csv(index=False).encode("utf-8"), file_name=name, mime="text/csv",
                       key=key)


def money(x: float) -> str:
    return f"{x:,.0f}"
