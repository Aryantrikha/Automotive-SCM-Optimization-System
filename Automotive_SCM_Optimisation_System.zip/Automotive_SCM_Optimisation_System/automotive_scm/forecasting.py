"""Demand forecasting: moving average, seasonal naive, exponential smoothing.

All forecasters take a 1-D sequence of non-negative monthly demand values and a
horizon (number of future months). Forecasts are returned as floats; the
DataFrame helper rounds to whole units.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

METHODS = ("moving_average", "seasonal_naive", "exp_smoothing")


def _clean(values, min_len: int = 1) -> np.ndarray:
    arr = np.asarray(values, dtype=float)
    if arr.ndim != 1 or arr.size < min_len:
        raise ValueError(f"Need a 1-D series with at least {min_len} observations")
    if np.isnan(arr).any():
        raise ValueError("Series contains missing values")
    if (arr < 0).any():
        raise ValueError("Demand values must be non-negative")
    return arr


def _check_horizon(horizon: int) -> int:
    if int(horizon) != horizon or horizon < 1:
        raise ValueError("horizon must be a positive integer")
    return int(horizon)


def moving_average_forecast(values, horizon: int, window: int = 3) -> np.ndarray:
    """Recursive moving average: each forecast is the mean of the last `window`
    points, where previously forecast points are fed back in."""
    arr = _clean(values)
    horizon = _check_horizon(horizon)
    if window < 1 or int(window) != window:
        raise ValueError("window must be a positive integer")
    if window > arr.size:
        raise ValueError(f"window ({window}) exceeds history length ({arr.size})")
    hist = list(arr)
    out = []
    for _ in range(horizon):
        f = float(np.mean(hist[-int(window):]))
        out.append(f)
        hist.append(f)
    return np.array(out)


def seasonal_naive_forecast(values, horizon: int, season_length: int = 12) -> np.ndarray:
    """Forecast = value observed one season ago."""
    horizon = _check_horizon(horizon)
    if season_length < 1:
        raise ValueError("season_length must be >= 1")
    arr = _clean(values, min_len=int(season_length))
    base = arr[-int(season_length):]
    return np.array([base[h % int(season_length)] for h in range(horizon)], dtype=float)


def exp_smoothing_forecast(values, horizon: int, alpha: float = 0.4) -> np.ndarray:
    """Simple exponential smoothing (flat forecast at the final level)."""
    arr = _clean(values)
    horizon = _check_horizon(horizon)
    if not 0 < alpha <= 1:
        raise ValueError("alpha must satisfy 0 < alpha <= 1")
    level = arr[0]
    for x in arr[1:]:
        level = alpha * x + (1 - alpha) * level
    return np.full(horizon, level, dtype=float)


def forecast_series(values, method: str, horizon: int, ma_window: int = 3,
                    alpha: float = 0.4, season_length: int = 12) -> np.ndarray:
    """Dispatch to a forecasting method by name."""
    if method == "moving_average":
        return moving_average_forecast(values, horizon, ma_window)
    if method == "seasonal_naive":
        return seasonal_naive_forecast(values, horizon, season_length)
    if method == "exp_smoothing":
        return exp_smoothing_forecast(values, horizon, alpha)
    raise ValueError(f"Unknown forecasting method '{method}'. Choose from {METHODS}")


def _monthly_series(history: pd.DataFrame, material_id: str) -> pd.Series:
    sub = history[history["material_id"] == material_id]
    s = sub.groupby("month")["demand"].sum().sort_index()
    expected = pd.date_range(s.index.min(), s.index.max(), freq="MS")
    if len(expected) != len(s) or not (expected == s.index).all():
        raise ValueError(f"Demand history for {material_id} has missing months")
    return s


def forecast_demand(history: pd.DataFrame, method: str = "moving_average", horizon: int = 6,
                    ma_window: int = 3, alpha: float = 0.4, season_length: int = 12) -> pd.DataFrame:
    """Forecast every material in a long-format history (month, material_id, demand).

    Returns: material_id, period_start, forecast_qty, method. Forecast starts the
    month after the last history month.
    """
    for col in ("month", "material_id", "demand"):
        if col not in history.columns:
            raise ValueError(f"history is missing column '{col}'")
    if history.empty:
        raise ValueError("history is empty")
    hist = history.copy()
    hist["month"] = pd.to_datetime(hist["month"])
    horizon = _check_horizon(horizon)
    frames = []
    for mat in sorted(hist["material_id"].unique()):
        s = _monthly_series(hist, mat)
        fc = forecast_series(s.values, method, horizon, ma_window, alpha, season_length)
        periods = pd.date_range(s.index.max() + pd.offsets.MonthBegin(1), periods=horizon, freq="MS")
        frames.append(pd.DataFrame({"material_id": mat, "period_start": periods,
                                    "forecast_qty": np.round(fc).astype(int), "method": method}))
    return pd.concat(frames, ignore_index=True)


def evaluate_methods(values, test_months: int = 3, ma_window: int = 3, alpha: float = 0.4,
                     season_length: int = 12) -> pd.DataFrame:
    """Hold-out back-test: train on all but the last `test_months`, compare methods."""
    arr = _clean(values, min_len=test_months + 2)
    train, test = arr[:-test_months], arr[-test_months:]
    rows = []
    for method in METHODS:
        try:
            fc = forecast_series(train, method, test_months, ma_window, alpha, season_length)
        except ValueError:
            rows.append({"method": method, "MAE": np.nan, "MAPE_%": np.nan, "bias": np.nan})
            continue
        err = fc - test
        nz = test != 0
        mape = float(np.mean(np.abs(err[nz] / test[nz])) * 100) if nz.any() else np.nan
        rows.append({"method": method, "MAE": float(np.mean(np.abs(err))),
                     "MAPE_%": mape, "bias": float(np.mean(err))})
    return pd.DataFrame(rows)


def historical_vs_forecast(history: pd.DataFrame, forecast: pd.DataFrame) -> pd.DataFrame:
    """Combine history and forecast into one long frame for charting."""
    h = history.rename(columns={"month": "period", "demand": "quantity"})[["material_id", "period", "quantity"]]
    h = h.assign(kind="History")
    f = forecast.rename(columns={"period_start": "period", "forecast_qty": "quantity"})[["material_id", "period", "quantity"]]
    f = f.assign(kind="Forecast")
    out = pd.concat([h, f], ignore_index=True)
    out["period"] = pd.to_datetime(out["period"])
    return out.sort_values(["material_id", "period"]).reset_index(drop=True)
