import pandas as pd
import pytest

from automotive_scm import mrp

START = pd.Timestamp("2026-01-01")


def mats(rows):
    cols = ["material_id", "description", "material_type", "uom", "procurement_type", "lot_size_rule", "lot_size",
            "lead_time_days", "safety_stock", "unit_cost", "supplier_id", "plant_id"]
    return pd.DataFrame(rows, columns=cols)


def inv(d):
    return pd.DataFrame([(m, "P", q, START) for m, q in d.items()], columns=["material_id", "plant_id", "on_hand", "last_movement_date"])


NO_RECEIPTS = pd.DataFrame(columns=["po_id", "material_id", "supplier_id", "quantity", "due_date"])


def fcst(qty_by_month, mat="FG"):
    return pd.DataFrame({"material_id": mat, "period_start": [START + pd.DateOffset(months=i) for i in range(len(qty_by_month))],
                         "forecast_qty": qty_by_month})


def test_lot_sizing_rules():
    assert mrp.apply_lot_size(0, "LFL", 0) == 0
    assert mrp.apply_lot_size(101.2, "LFL", 0) == 102
    assert mrp.apply_lot_size(101, "FIXED", 50) == 150
    assert mrp.apply_lot_size(100, "FIXED", 50) == 100
    with pytest.raises(ValueError):
        mrp.apply_lot_size(10, "FIXED", 0)
    with pytest.raises(ValueError):
        mrp.apply_lot_size(10, "XYZ", 0)


def simple_setup(rule="LFL", lot=0, ss=0, comp_lt=10, stock_fg=0, stock_c=0):
    m = mats([("FG", "Finished", "FERT", "EA", "In-house", "LFL", 0, 2, 0, 10, "", "P"),
              ("C1", "Comp", "ROH", "EA", "External", rule, lot, comp_lt, ss, 1, "S1", "P")])
    bom = pd.DataFrame([("FG", "C1", 2, 0.0, "A")], columns=["parent_id", "component_id", "quantity", "scrap_pct", "revision"])
    return m, bom, inv({"FG": stock_fg, "C1": stock_c})


def test_netting_against_inventory_and_lot_for_lot():
    m, bom, i = simple_setup(stock_fg=300, stock_c=500)
    r = mrp.run_mrp(m, bom, i, NO_RECEIPTS, fcst([1000]), START, 1)
    fg = r.planned_orders.query("material_id == 'FG'").iloc[0]
    assert fg.quantity == 700                       # 1000 - 300 stock
    c = r.planned_orders.query("material_id == 'C1'").iloc[0]
    assert c.quantity == 700 * 2 - 500              # dependent demand netted against stock
    assert c.order_type == "Purchase Requisition"


def test_scheduled_receipts_reduce_net_requirement():
    m, bom, i = simple_setup(stock_fg=0, stock_c=0)
    rec = pd.DataFrame([("PO1", "C1", "S1", 1000, pd.Timestamp("2026-01-05"))], columns=NO_RECEIPTS.columns)
    r = mrp.run_mrp(m, bom, i, rec, fcst([500]), START, 1)
    assert r.grid.query("material_id == 'C1'").iloc[0].scheduled_receipts == 1000
    assert r.planned_orders[r.planned_orders.material_id == "C1"].empty  # 1000 needed, 1000 received


def test_safety_stock_is_maintained():
    m, bom, i = simple_setup(ss=300, stock_c=1000)
    r = mrp.run_mrp(m, bom, i, NO_RECEIPTS, fcst([500]), START, 1)
    c = r.planned_orders.query("material_id == 'C1'").iloc[0]
    assert c.quantity == 1000 + 300 - 1000          # gross 1000, SS 300, stock 1000
    g = r.grid.query("material_id == 'C1'").iloc[0]
    assert g.projected_stock == 300
    r2 = mrp.run_mrp(m, bom, i, NO_RECEIPTS, fcst([500]), START, 1, use_safety_stock=False)
    assert r2.planned_orders[r2.planned_orders.material_id == "C1"].empty


def test_fixed_lot_size_rounds_up_and_carries_surplus():
    m, bom, i = simple_setup(rule="FIXED", lot=800)
    r = mrp.run_mrp(m, bom, i, NO_RECEIPTS, fcst([500, 500]), START, 2)
    c = r.planned_orders[r.planned_orders.material_id == "C1"]
    assert c.quantity.tolist() == [1600, 800]   # month 1: 1000 -> 2 lots; month 2: 1000-600 carried = 400 -> 1 lot
    g = r.grid[r.grid.material_id == "C1"].reset_index(drop=True)
    assert g.projected_stock[0] == 600
    assert g.net_requirement[1] == 400
    assert g.projected_stock[1] == 400


def test_lead_time_offset_and_past_due_flag():
    m, bom, i = simple_setup(comp_lt=45)
    r = mrp.run_mrp(m, bom, i, NO_RECEIPTS, fcst([500]), START, 1)
    c = r.planned_orders.query("material_id == 'C1'").iloc[0]
    assert (c.need_date - c.release_date).days == 45
    assert c.past_due and c.days_late > 0
    assert (r.shortages["alert_type"] == "Lead-time violation (expedite)").any()
    assert r.shortages.query("material_id == 'C1'").iloc[0].severity == "Critical"


def test_not_past_due_when_lead_time_short():
    m, bom, i = simple_setup(comp_lt=1)
    r = mrp.run_mrp(m, bom, i, NO_RECEIPTS, fcst([500]), START, 1)
    assert not r.planned_orders.query("material_id == 'C1'").iloc[0].past_due


def test_below_safety_stock_alert():
    m, bom, i = simple_setup(ss=800, stock_c=100)
    r = mrp.run_mrp(m, bom, i, NO_RECEIPTS, fcst([0]), START, 1)
    assert ((r.shortages.material_id == "C1") & (r.shortages.alert_type == "Below safety stock")).any()


def test_multilevel_dependent_demand_flows_through_levels():
    m = mats([("FG", "F", "FERT", "EA", "In-house", "LFL", 0, 1, 0, 1, "", "P"),
              ("SA", "S", "HALB", "EA", "In-house", "LFL", 0, 1, 0, 1, "", "P"),
              ("RM", "R", "ROH", "EA", "External", "LFL", 0, 1, 0, 1, "S1", "P")])
    bom = pd.DataFrame([("FG", "SA", 2, 0.0, "A"), ("SA", "RM", 3, 0.0, "A")],
                       columns=["parent_id", "component_id", "quantity", "scrap_pct", "revision"])
    r = mrp.run_mrp(m, bom, inv({"FG": 0, "SA": 0, "RM": 0}), NO_RECEIPTS, fcst([100]), START, 1)
    q = r.planned_orders.set_index("material_id").quantity
    assert q["FG"] == 100 and q["SA"] == 200 and q["RM"] == 600


def test_circular_bom_stops_mrp():
    from automotive_scm.bom import CircularBOMError
    m = mats([("A", "A", "FERT", "EA", "In-house", "LFL", 0, 1, 0, 1, "", "P"),
              ("B", "B", "HALB", "EA", "In-house", "LFL", 0, 1, 0, 1, "", "P")])
    bom = pd.DataFrame([("A", "B", 1, 0.0, "A"), ("B", "A", 1, 0.0, "A")],
                       columns=["parent_id", "component_id", "quantity", "scrap_pct", "revision"])
    with pytest.raises(CircularBOMError):
        mrp.run_mrp(m, bom, inv({"A": 0, "B": 0}), NO_RECEIPTS, fcst([10], "A"), START, 1)


def test_input_validation():
    m, bom, i = simple_setup()
    with pytest.raises(ValueError):
        mrp.run_mrp(m, bom, i, NO_RECEIPTS, fcst([1]), pd.Timestamp("2026-01-15"), 1)
    with pytest.raises(ValueError):
        mrp.run_mrp(m, bom, i, NO_RECEIPTS, fcst([1]).iloc[0:0], START, 1)
    with pytest.raises(ValueError):
        mrp.run_mrp(m, bom, i, NO_RECEIPTS, fcst([1], "UNKNOWN"), START, 1)


def test_project_pipeline_conservation():
    """On the synthetic dataset, projected stock never falls below zero after planned receipts
    except where lead times force a late release (flagged past-due)."""
    from automotive_scm.pipeline import run_pipeline
    cfg_res = run_pipeline(data=_load())
    grid = cfg_res["mrp"].grid
    assert (grid["projected_stock"] >= -1e-6).all()


def _load():
    from automotive_scm import datagen
    from automotive_scm.data_loader import validate_table, validate_dataset
    t = datagen.generate_all()
    t = {k: validate_table(k, v) for k, v in t.items()}
    validate_dataset(t)
    return t


# ---- execution simulation (kept here to stay within the required test files) ----
def test_execution_status_flow_and_movements():
    from automotive_scm import execution as ex
    bom = pd.DataFrame([("FG", "C1", 2, 0.0, "A")], columns=["parent_id", "component_id", "quantity", "scrap_pct", "revision"])
    orders = pd.DataFrame([("O1", "FG", 100.0, START, START + pd.Timedelta(days=3), "Created", 0.0)],
                          columns=["order_id", "material_id", "planned_qty", "start_date", "due_date", "status", "actual_qty"])
    orders["actual_start"] = pd.NaT
    orders["actual_end"] = pd.NaT
    mv = pd.DataFrame(columns=ex.MOVEMENT_COLS)
    for expected in ("Released", "In Progress", "Completed"):
        orders, mv = ex.advance_order(orders, mv, "O1", bom, START + pd.Timedelta(days=5))
        assert orders.iloc[0].status == expected
    gi = mv[mv.movement_type == "GI"]
    gr = mv[mv.movement_type == "GR"]
    assert gi.quantity.iloc[0] == -200 and gi.material_id.iloc[0] == "C1"
    assert gr.quantity.sum() == round(100 * 0.985)
    assert orders.iloc[0].delay_days == 2
    with pytest.raises(ValueError):
        ex.advance_order(orders, mv, "O1", bom, START)
    with pytest.raises(ValueError):
        ex.advance_order(orders, mv, "NOPE", bom, START)


def test_pipeline_execution_invariants():
    from automotive_scm.pipeline import run_pipeline
    r = run_pipeline(data=_load())
    o = r["execution_orders"]
    assert set(o.status) <= {"Created", "Released", "In Progress", "Completed"}
    assert (o[o.status == "Created"].actual_qty == 0).all()
    assert (o[o.status == "Completed"].actual_qty <= o[o.status == "Completed"].planned_qty).all()
    assert r["capacity_util_baseline"]["utilisation"].notna().all()
