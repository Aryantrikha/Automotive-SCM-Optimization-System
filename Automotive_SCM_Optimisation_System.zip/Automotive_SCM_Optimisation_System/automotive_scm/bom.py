"""Multi-level Bill of Materials (BOM) utilities.

Supports recursive explosion, circular-reference detection, low-level codes
and where-used analysis. BOM rows have: parent_id, component_id, quantity and
optionally scrap_pct (percent, e.g. 2 means 2 %).
"""
from __future__ import annotations

from collections import defaultdict
from typing import Iterable, Mapping

import pandas as pd


class BOMError(ValueError):
    """Raised for structurally invalid BOM data."""


class CircularBOMError(BOMError):
    """Raised when the BOM contains a circular (recursive) reference."""

    def __init__(self, cycle: Iterable[str]):
        self.cycle = list(cycle)
        super().__init__("Circular BOM reference detected: " + " -> ".join(self.cycle))


def build_graph(bom: pd.DataFrame) -> dict[str, list[tuple[str, float, float]]]:
    """Return {parent: [(component, effective_qty, raw_qty), ...]}.

    effective_qty includes scrap: quantity * (1 + scrap_pct / 100).
    """
    for col in ("parent_id", "component_id", "quantity"):
        if col not in bom.columns:
            raise BOMError(f"BOM is missing required column '{col}'")
    scrap = bom["scrap_pct"] if "scrap_pct" in bom.columns else pd.Series(0.0, index=bom.index)
    graph: dict[str, list[tuple[str, float, float]]] = defaultdict(list)
    for parent, comp, qty, sc in zip(bom["parent_id"], bom["component_id"], bom["quantity"], scrap.fillna(0.0)):
        graph[str(parent)].append((str(comp), float(qty) * (1.0 + float(sc) / 100.0), float(qty)))
    return dict(graph)


def find_circular_reference(bom: pd.DataFrame) -> list[str]:
    """Return one cycle as a list of ids (first == last), or [] if the BOM is acyclic."""
    graph = build_graph(bom)
    colour: dict[str, int] = defaultdict(int)  # 0 white, 1 grey, 2 black
    for root in list(graph):
        if colour[root] != 0:
            continue
        colour[root] = 1
        path = [root]
        stack = [(root, iter(graph.get(root, [])))]
        while stack:
            node, children = stack[-1]
            advanced = False
            for child, *_ in children:
                if colour[child] == 1:
                    return path[path.index(child):] + [child]
                if colour[child] == 0:
                    colour[child] = 1
                    path.append(child)
                    stack.append((child, iter(graph.get(child, []))))
                    advanced = True
                    break
            if not advanced:
                colour[node] = 2
                path.pop()
                stack.pop()
    return []


def validate_bom(bom: pd.DataFrame, material_ids: Iterable[str] | None = None) -> None:
    """Validate BOM structure; raises BOMError / CircularBOMError."""
    build_graph(bom)  # column check
    if bom.empty:
        raise BOMError("BOM is empty")
    if (pd.to_numeric(bom["quantity"], errors="coerce").fillna(-1) <= 0).any():
        raise BOMError("BOM quantities must be positive numbers")
    if bom.duplicated(["parent_id", "component_id"]).any():
        raise BOMError("Duplicate parent/component pairs in BOM")
    if material_ids is not None:
        known = set(map(str, material_ids))
        unknown = (set(bom["parent_id"].astype(str)) | set(bom["component_id"].astype(str))) - known
        if unknown:
            raise BOMError(f"BOM references materials missing from material master: {sorted(unknown)}")
    cycle = find_circular_reference(bom)
    if cycle:
        raise CircularBOMError(cycle)


def low_level_codes(bom: pd.DataFrame, material_ids: Iterable[str] | None = None) -> dict[str, int]:
    """Low-level code = deepest level at which a material appears (0 = top level)."""
    graph = build_graph(bom)
    nodes = set(graph) | {c for kids in graph.values() for c, *_ in kids}
    if material_ids is not None:
        nodes |= set(map(str, material_ids))
    indegree = {n: 0 for n in nodes}
    for kids in graph.values():
        for child, *_ in kids:
            indegree[child] += 1
    llc = {n: 0 for n in nodes}
    queue = [n for n, d in indegree.items() if d == 0]
    processed = 0
    while queue:
        node = queue.pop()
        processed += 1
        for child, *_ in graph.get(node, []):
            llc[child] = max(llc[child], llc[node] + 1)
            indegree[child] -= 1
            if indegree[child] == 0:
                queue.append(child)
    if processed != len(nodes):
        raise CircularBOMError(find_circular_reference(bom))
    return llc


def explode_bom(bom: pd.DataFrame, parent: str, quantity: float = 1.0,
                include_scrap: bool = True) -> pd.DataFrame:
    """Recursively explode `parent` into all component levels.

    Returns columns: level, parent_id, component_id, qty_per_parent,
    extended_qty (total needed for `quantity` of the top parent) and path.
    """
    if quantity < 0:
        raise ValueError("quantity must be non-negative")
    graph = build_graph(bom)
    parent = str(parent)
    if parent not in graph:
        raise BOMError(f"'{parent}' has no BOM")
    rows: list[dict] = []

    def walk(node: str, qty: float, level: int, path: tuple[str, ...]) -> None:
        for child, eff, raw in graph.get(node, []):
            if child in path:
                raise CircularBOMError(list(path) + [child])
            per = eff if include_scrap else raw
            ext = qty * per
            rows.append({"level": level, "parent_id": node, "component_id": child,
                         "qty_per_parent": per, "extended_qty": ext,
                         "path": " > ".join(path + (child,))})
            walk(child, ext, level + 1, path + (child,))

    walk(parent, float(quantity), 1, (parent,))
    return pd.DataFrame(rows, columns=["level", "parent_id", "component_id",
                                       "qty_per_parent", "extended_qty", "path"])


def explode_demand(bom: pd.DataFrame, demand: Mapping[str, float],
                   include_scrap: bool = True) -> pd.DataFrame:
    """Convert finished-product demand into gross (un-netted) component requirements.

    Returns columns: component_id, gross_requirement, min_level.
    """
    frames = []
    for product, qty in demand.items():
        if qty and qty > 0:
            frames.append(explode_bom(bom, product, float(qty), include_scrap))
    if not frames:
        return pd.DataFrame(columns=["component_id", "gross_requirement", "min_level"])
    allrows = pd.concat(frames, ignore_index=True)
    out = (allrows.groupby("component_id")
           .agg(gross_requirement=("extended_qty", "sum"), min_level=("level", "min"))
           .reset_index())
    return out.sort_values(["min_level", "component_id"]).reset_index(drop=True)


def where_used(bom: pd.DataFrame, component: str) -> pd.DataFrame:
    """All parents (direct and indirect) that consume `component`."""
    component = str(component)
    parents_of: dict[str, list[str]] = defaultdict(list)
    for p, c in zip(bom["parent_id"].astype(str), bom["component_id"].astype(str)):
        parents_of[c].append(p)
    rows: list[dict] = []

    def walk(node: str, level: int, seen: tuple[str, ...]) -> None:
        for p in parents_of.get(node, []):
            if p in seen:
                raise CircularBOMError(list(seen) + [p])
            rows.append({"level": level, "component_id": node, "used_in": p})
            walk(p, level + 1, seen + (p,))

    walk(component, 1, (component,))
    return pd.DataFrame(rows, columns=["level", "component_id", "used_in"])
