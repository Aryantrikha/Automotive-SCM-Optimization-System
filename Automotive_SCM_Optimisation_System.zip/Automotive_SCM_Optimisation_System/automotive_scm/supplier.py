"""Supplier management: OTD performance, risk scoring, replenishment recommendations."""
from __future__ import annotations

import numpy as np
import pandas as pd

RATING_POINTS = {"A": 0.0, "B": 7.0, "C": 15.0}


def delivery_performance(deliveries: pd.DataFrame) -> pd.DataFrame:
    """OTD %, in-full %, avg lateness of late deliveries, actual lead time, per supplier."""
    d = deliveries.copy()
    d["late_days"] = (d["actual_date"] - d["promised_date"]).dt.days
    d["on_time"] = d["late_days"] <= 0
    d["in_full"] = d["qty_received"] >= d["qty_ordered"]
    d["actual_lead_time"] = (d["actual_date"] - d["order_date"]).dt.days
    g = d.groupby("supplier_id").agg(
        deliveries=("delivery_id", "count"), otd_rate=("on_time", "mean"), in_full_rate=("in_full", "mean"),
        avg_actual_lead_time=("actual_lead_time", "mean"), lead_time_std=("actual_lead_time", "std"))
    late = d[~d["on_time"]].groupby("supplier_id")["late_days"].mean().rename("avg_delay_days_when_late")
    return g.join(late).fillna({"avg_delay_days_when_late": 0.0, "lead_time_std": 0.0}).reset_index()


def monthly_otd(deliveries: pd.DataFrame) -> pd.DataFrame:
    """On-time delivery trend by promised month and supplier."""
    d = deliveries.copy()
    d["on_time"] = d["actual_date"] <= d["promised_date"]
    d["month"] = d["promised_date"].dt.to_period("M").dt.to_timestamp()
    return d.groupby(["supplier_id", "month"])["on_time"].mean().rename("otd_rate").reset_index()


def risk_scores(suppliers: pd.DataFrame, materials: pd.DataFrame, perf: pd.DataFrame,
                high: float = 60, medium: float = 35) -> pd.DataFrame:
    """Composite 0-100 supplier risk score and High/Medium/Low classification.

    Components (max points): on-time delivery gap 35, delay severity 15, quality (ppm) 10,
    single-source dependency 15, financial rating 15, lead-time exposure 10.
    """
    lt = materials[materials["procurement_type"] == "External"].groupby("supplier_id").agg(
        avg_material_lead_time=("lead_time_days", "mean"), max_material_lead_time=("lead_time_days", "max"),
        materials_supplied=("material_id", "count"))
    df = suppliers.merge(perf, on="supplier_id", how="left").merge(lt, on="supplier_id", how="left")
    df["otd_rate"] = df["otd_rate"].fillna(0.0)
    df["pts_otd"] = ((0.98 - df["otd_rate"]) / 0.30).clip(0, 1) * 35
    df["pts_delay"] = (df["avg_delay_days_when_late"].fillna(0) / 10).clip(0, 1) * 15
    df["pts_quality"] = (df["quality_ppm"] / 2000).clip(0, 1) * 10
    df["pts_single"] = np.where(df["single_source"] == 1, 15.0, 0.0)
    df["pts_fin"] = df["financial_rating"].map(RATING_POINTS).fillna(15.0)
    df["pts_lt"] = (df["avg_material_lead_time"].fillna(0) / 60).clip(0, 1) * 10
    df["risk_score"] = df[["pts_otd", "pts_delay", "pts_quality", "pts_single", "pts_fin", "pts_lt"]].sum(axis=1).round(1)
    df["risk_class"] = np.select([df["risk_score"] >= high, df["risk_score"] >= medium], ["High", "Medium"], "Low")
    return df


def critical_long_lead(materials: pd.DataFrame, suppliers: pd.DataFrame, risk: pd.DataFrame,
                       threshold_days: int = 35) -> pd.DataFrame:
    """External materials whose lead time is at/above the threshold."""
    m = materials[(materials["procurement_type"] == "External") & (materials["lead_time_days"] >= threshold_days)]
    m = m.merge(suppliers[["supplier_id", "name"]], on="supplier_id", how="left").merge(
        risk[["supplier_id", "risk_class", "otd_rate"]], on="supplier_id", how="left")
    return m[["material_id", "description", "lead_time_days", "safety_stock", "supplier_id", "name", "risk_class",
              "otd_rate"]].sort_values("lead_time_days", ascending=False).reset_index(drop=True)


def replenishment_recommendations(planned_orders: pd.DataFrame, risk: pd.DataFrame, suppliers: pd.DataFrame,
                                  start_date, long_lead_days: int = 35) -> pd.DataFrame:
    """Purchase recommendations from MRP planned purchase requisitions, with supplier risk context."""
    start = pd.Timestamp(start_date)
    po = planned_orders[planned_orders["order_type"] == "Purchase Requisition"].copy()
    cols = ["planned_order_id", "material_id", "description", "supplier_id", "supplier_name", "quantity", "uom",
            "release_date", "need_date", "lead_time_days", "supplier_risk", "otd_rate", "action", "comment"]
    if po.empty:
        return pd.DataFrame(columns=cols)
    po = po.merge(suppliers[["supplier_id", "name"]].rename(columns={"name": "supplier_name"}), on="supplier_id", how="left")
    po = po.merge(risk[["supplier_id", "risk_class", "otd_rate"]].rename(columns={"risk_class": "supplier_risk"}),
                  on="supplier_id", how="left")

    def rec(r):
        notes = []
        if r.past_due:
            action = "EXPEDITE"
            notes.append(f"Release was due {r.days_late} day(s) ago; ask supplier for earliest feasible date")
        elif (r.release_date - start).days <= 7:
            action = "Release now"
        else:
            action = "Plan"
        if r.supplier_risk == "High":
            notes.append("High-risk supplier: add buffer stock / qualify second source")
        elif r.supplier_risk == "Medium" and r.lead_time_days >= long_lead_days:
            notes.append("Long lead time with medium-risk supplier: monitor closely")
        if r.lead_time_days >= long_lead_days:
            notes.append("Critical long-lead item")
        return pd.Series({"action": action, "comment": "; ".join(notes)})

    po[["action", "comment"]] = po.apply(rec, axis=1)
    order = {"EXPEDITE": 0, "Release now": 1, "Plan": 2}
    po["_o"] = po["action"].map(order)
    return po.sort_values(["_o", "release_date"])[cols].reset_index(drop=True)
