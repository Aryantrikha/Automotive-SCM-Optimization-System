"""End-to-end planning pipeline used by the demo script and the dashboard."""
from __future__ import annotations

import copy
from pathlib import Path

import pandas as pd

from . import (bom as bomlib, capacity, database, execution, forecasting, inventory as invlib, kpis, mrp,
               production, supplier)
from .data_loader import load_config, load_raw, resolve_path

PRODUCTS = ["GBX-100", "PMP-200"]


def run_pipeline(config: dict | None = None, data: dict | None = None, overrides: dict | None = None) -> dict:
    """Run forecast -> MRP -> production -> capacity -> supplier -> execution -> KPIs.

    `overrides` may contain: horizon_months, method, ma_window, alpha, use_safety_stock.
    """
    cfg = copy.deepcopy(config or load_config())
    ov = overrides or {}
    if "horizon_months" in ov:
        cfg["planning"]["horizon_months"] = int(ov["horizon_months"])
    for k in ("method", "ma_window", "alpha"):
        if k in ov:
            cfg["forecasting"][k] = ov[k]
    if "use_safety_stock" in ov:
        cfg.setdefault("mrp", {})["use_safety_stock"] = bool(ov["use_safety_stock"])
    if data is None:
        data = load_raw(config=cfg)
    p, f, t = cfg["planning"], cfg["forecasting"], cfg["thresholds"]
    horizon = int(p["horizon_months"])
    start = pd.Timestamp(p["start_date"])
    as_of = pd.Timestamp(p["as_of_date"])
    wdays = int(p["working_days_per_month"])
    periods = [start + pd.DateOffset(months=i) for i in range(horizon)]

    last_hist = data["demand_history"]["month"].max()
    if start != last_hist + pd.offsets.MonthBegin(1):
        raise ValueError(f"planning.start_date ({start.date()}) must be the month after the last demand "
                         f"history month ({last_hist.date()})")

    fc = forecasting.forecast_demand(data["demand_history"], f["method"], horizon, f.get("ma_window", 3),
                                     f.get("alpha", 0.4), f.get("season_length", 12))
    res = mrp.run_mrp(data["materials"], data["bom"], data["inventory"], data["scheduled_receipts"], fc, start,
                      horizon, cfg.get("mrp", {}).get("use_safety_stock", True), t["long_lead_time_days"])
    plan = production.production_plan(res.grid, fc, PRODUCTS)
    orders = production.create_production_orders(res.planned_orders, start)
    orders = production.check_component_availability(orders, data["bom"], data["inventory"],
                                                     data["scheduled_receipts"], res.planned_orders)
    loads, util_base = capacity.baseline_capacity(orders, data["routings"], data["work_centres"], periods, wdays,
                                                  t["capacity_warning"], t["capacity_overload"])
    assign, util_opt = capacity.optimise_allocation(loads, data["work_centres"], periods, wdays,
                                                    t["capacity_warning"], t["capacity_overload"])
    ex = cfg.get("execution", {})
    exec_orders, movements = execution.simulate_execution(
        orders, data["bom"], as_of, ex.get("seed", 7), ex.get("yield_mean", 0.985), ex.get("yield_sd", 0.02),
        ex.get("release_window_days", 30), data["scheduled_receipts"], res.planned_orders)
    inv_after = execution.apply_movements(data["inventory"], movements)

    monthly = invlib.monthly_demand_from_mrp(res.grid, horizon)
    inv_status = invlib.inventory_status(data["materials"], data["inventory"], data["scheduled_receipts"], monthly,
                                         start, t.get("excess_days_of_cover", 90))
    perf = supplier.delivery_performance(data["supplier_deliveries"])
    risk = supplier.risk_scores(data["suppliers"], data["materials"], perf, t["supplier_high_risk_score"],
                                t["supplier_medium_risk_score"])
    results = {
        "config": cfg, "data": data, "periods": periods, "start_date": start, "as_of_date": as_of,
        "forecast": fc, "mrp": res, "production_plan": plan, "production_orders": orders,
        "operation_loads": loads, "capacity_util_baseline": util_base, "capacity_assignments": assign,
        "capacity_util_optimised": util_opt, "capacity_alerts": capacity.over_capacity_alerts(util_base),
        "execution_orders": exec_orders, "goods_movements": movements, "inventory_after_execution": inv_after,
        "inventory_status": inv_status, "supplier_perf": perf, "supplier_risk": risk,
        "long_lead": supplier.critical_long_lead(data["materials"], data["suppliers"], risk, t["long_lead_time_days"]),
        "replenishment": supplier.replenishment_recommendations(res.planned_orders, risk, data["suppliers"], start,
                                                                t["long_lead_time_days"]),
        "model_comparison": {m: forecasting.evaluate_methods(
            data["demand_history"][data["demand_history"]["material_id"] == m].sort_values("month")["demand"].values,
            3, f.get("ma_window", 3), f.get("alpha", 0.4), f.get("season_length", 12)) for m in PRODUCTS},
    }
    results["kpis"] = kpis.compute_kpis(results)
    return results


OUTPUT_TABLES = {
    "demand_forecast.csv": "forecast",
    "mrp_grid.csv": lambda r: r["mrp"].grid,
    "mrp_planned_orders.csv": lambda r: r["mrp"].planned_orders,
    "shortage_alerts.csv": lambda r: r["mrp"].shortages,
    "production_plan.csv": "production_plan",
    "production_orders.csv": "production_orders",
    "capacity_utilisation_baseline.csv": "capacity_util_baseline",
    "capacity_utilisation_optimised.csv": "capacity_util_optimised",
    "capacity_alerts.csv": "capacity_alerts",
    "capacity_assignments.csv": "capacity_assignments",
    "inventory_status.csv": "inventory_status",
    "supplier_risk.csv": "supplier_risk",
    "replenishment_recommendations.csv": "replenishment",
    "execution_orders.csv": "execution_orders",
    "goods_movements.csv": "goods_movements",
    "kpi_summary.csv": lambda r: kpis.kpi_table(r["kpis"]),
}


def write_outputs(results: dict, out_dir: str | Path | None = None, db_path: str | Path | None = None) -> list[Path]:
    """Write result CSVs (and a SQLite database) and return the CSV paths."""
    cfg = results["config"]
    out = Path(out_dir) if out_dir else resolve_path(cfg["paths"]["outputs"])
    out.mkdir(parents=True, exist_ok=True)
    paths, db_tables = [], {}
    for fname, src in OUTPUT_TABLES.items():
        df = src(results) if callable(src) else results[src]
        p = out / fname
        df.to_csv(p, index=False, date_format="%Y-%m-%d")
        paths.append(p)
        db_tables[fname[:-4]] = df
    conn = database.connect(db_path or resolve_path(cfg["paths"]["database"]))
    try:
        database.save_master(conn, results["data"])
        database.save_results(conn, db_tables)
    finally:
        conn.close()
    return paths
