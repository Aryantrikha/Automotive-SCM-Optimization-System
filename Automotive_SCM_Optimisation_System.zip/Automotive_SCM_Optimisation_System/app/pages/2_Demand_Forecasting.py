import plotly.express as px
import streamlit as st

import common as c
from automotive_scm import forecasting

c.setup_page("Demand Forecasting", "📈")
res = c.header("Demand Forecasting", "Synthetic 24-month history; moving average, seasonal naive or exponential smoothing")
hist = res["data"]["demand_history"]
fc = res["forecast"]
products = sorted(hist["material_id"].unique())
mat = res["data"]["materials"].set_index("material_id")["description"]

sel = st.multiselect("Products", products, default=products, format_func=lambda m: f"{m} - {mat[m]}")
if not sel:
    st.info("Select at least one product.")
    st.stop()

combo = forecasting.historical_vs_forecast(hist[hist["material_id"].isin(sel)], fc[fc["material_id"].isin(sel)])
fig = px.line(combo, x="period", y="quantity", color="material_id", line_dash="kind", markers=True,
              title=f"Historical vs forecast demand - {res['config']['forecasting']['method'].replace('_', ' ')}, "
                    f"{res['config']['planning']['horizon_months']}-month horizon",
              labels={"period": "", "quantity": "Units per month"})
st.plotly_chart(c.style_fig(fig, 460))

st.subheader("Forecast table")
tbl = fc[fc["material_id"].isin(sel)].copy()
tbl = c.fmt_period(tbl)
st.dataframe(tbl, hide_index=True)
c.download_button(fc, "demand_forecast.csv", "dl_fc")

st.subheader("Method back-test (hold out last 3 months)")
st.caption("Each method is trained on history excluding the last 3 months and scored on those 3 months. "
           "Lower MAE / MAPE is better.")
for m in sel:
    st.markdown(f"**{m} - {mat[m]}**")
    bt = res["model_comparison"][m].round(2)
    st.dataframe(bt, hide_index=True)
