"""Generate the synthetic raw CSV datasets into data/raw/.

Usage:  python scripts/generate_data.py [--seed 42]
"""
import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from automotive_scm import datagen  # noqa: E402
from automotive_scm.data_loader import SYNTHETIC_LABEL, load_config, resolve_path  # noqa: E402


def main() -> None:
    cfg = load_config()
    g = cfg.get("data_generation", {})
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--seed", type=int, default=g.get("seed", 42))
    args = ap.parse_args()
    tables = datagen.generate_all(args.seed, g.get("history_months", 24), g.get("history_end", "2025-12-01"))
    paths = datagen.write_raw_csvs(tables, resolve_path(cfg["paths"]["raw_data"]))
    (resolve_path(cfg["paths"]["raw_data"]) / "README_SYNTHETIC.txt").write_text(SYNTHETIC_LABEL + "\n", encoding="utf-8")
    print(SYNTHETIC_LABEL)
    for p in paths:
        print(f"  wrote {p.relative_to(resolve_path('.'))}  ({len(tables[p.stem])} rows)")


if __name__ == "__main__":
    main()
