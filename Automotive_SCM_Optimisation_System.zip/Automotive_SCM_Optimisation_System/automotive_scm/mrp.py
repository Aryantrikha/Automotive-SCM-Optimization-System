"""Time-phased Material Requirements Planning (MRP).

Monthly buckets. Procedure (conceptually similar to a classic MRP run):
  1. Independent demand = forecast of finished products (need date = mid-month).
  2. Materials are processed in low-level-code order so that all gross
     requirements of a material are known before it is netted.
  3. Net requirement = gross + safety stock - (projected stock + scheduled receipts).
  4. Lot sizing (lot-for-lot or fixed lot) gives the planned receipt.
  5. Planned release date = need date - lead time. In-house planned orders
     explode through the BOM into dependent demand at their release date.
Planned orders whose release date is before the run start are flagged past due
(the lead time cannot be met without expediting).
"""
from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np
import pandas as pd

from . import bom as bomlib

DEMAND_DUE_DAY_OFFSET = 14  # forecast demand is due mid-month


@dataclass
class MRPResult:
    grid: pd.DataFrame           # per material/period netting grid
    planned_orders: pd.DataFrame
    shortages: pd.DataFrame
    gross_requirements: pd.DataFrame  # total gross requirement per material over the horizon


def apply_lot_size(net: float, rule: str, lot_size: float) -> float:
    """Return planned order quantity for a net requirement."""
    if net <= 0:
        return 0.0
    if rule == "LFL":
        return float(math.ceil(net))
    if rule == "FIXED":
        if lot_size <= 0:
            raise ValueError("FIXED lot size rule requires lot_size > 0")
        return float(math.ceil(net / lot_size) * lot_size)
    raise ValueError(f"Unknown lot size rule '{rule}'")


def _period_index(date: pd.Timestamp, start: pd.Timestamp, horizon: int) -> int:
    idx = (date.year - start.year) * 12 + (date.month - start.month)
    return int(min(max(idx, 0), horizon - 1))


def run_mrp(materials: pd.DataFrame, bom: pd.DataFrame, inventory: pd.DataFrame, receipts: pd.DataFrame,
            forecast: pd.DataFrame, start_date, horizon: int, use_safety_stock: bool = True,
            long_lead_days: int = 35) -> MRPResult:
    """Run MRP for all materials. See module docstring for the logic."""
    start = pd.Timestamp(start_date).normalize()
    if start.day != 1:
        raise ValueError("MRP start_date must be the first day of a month")
    if horizon < 1:
        raise ValueError("horizon must be >= 1")
    if forecast.empty:
        raise ValueError("forecast is empty")
    bomlib.validate_bom(bom, materials["material_id"])
    llc = bomlib.low_level_codes(bom, materials["material_id"])
    graph = bomlib.build_graph(bom)

    periods = [start + pd.DateOffset(months=i) for i in range(horizon)]
    mat = materials.set_index("material_id")
    on_hand = inventory.groupby("material_id")["on_hand"].sum().to_dict()

    sr = {m: np.zeros(horizon) for m in mat.index}
    for r in receipts.itertuples():
        sr[r.material_id][_period_index(pd.Timestamp(r.due_date), start, horizon)] += float(r.quantity)

    gross = {m: np.zeros(horizon) for m in mat.index}
    need_dt: dict[str, list] = {m: [None] * horizon for m in mat.index}

    fc = forecast.copy()
    fc["period_start"] = pd.to_datetime(fc["period_start"])
    for r in fc.itertuples():
        if r.material_id not in gross:
            raise ValueError(f"Forecast for unknown material {r.material_id}")
        i = _period_index(r.period_start, start, horizon)
        gross[r.material_id][i] += float(r.forecast_qty)
        d = max(r.period_start + pd.Timedelta(days=DEMAND_DUE_DAY_OFFSET), start)
        cur = need_dt[r.material_id][i]
        need_dt[r.material_id][i] = d if cur is None else min(cur, d)

    grid_rows, order_rows, shortage_rows = [], [], []
    counter = 1
    ordered = sorted(mat.index, key=lambda m: (llc.get(m, 0), m))

    for m in ordered:
        row = mat.loc[m]
        lt = int(row["lead_time_days"])
        ss = float(row["safety_stock"]) if use_safety_stock else 0.0
        is_make = row["procurement_type"] == "In-house"
        proj = float(on_hand.get(m, 0.0))
        proj_no_supply = proj
        for t in range(horizon):
            g = gross[m][t]
            avail = proj + sr[m][t]
            net = max(0.0, g + ss - avail)
            planned = apply_lot_size(net, row["lot_size_rule"], float(row["lot_size"]))
            opening = proj
            proj = avail + planned - g
            proj_no_supply = proj_no_supply + sr[m][t] - g
            grid_rows.append({
                "material_id": m, "period_start": periods[t], "opening_stock": opening, "gross_requirement": g,
                "scheduled_receipts": sr[m][t], "net_requirement": net, "planned_receipt": planned,
                "projected_stock": proj, "safety_stock": ss, "projected_stock_no_new_supply": proj_no_supply,
            })
            if planned > 0:
                need = need_dt[m][t] if need_dt[m][t] is not None else max(periods[t], start)
                need = max(pd.Timestamp(need), start)
                release = need - pd.Timedelta(days=lt)
                past_due = release < start
                order_rows.append({
                    "planned_order_id": f"PLN-{counter:05d}", "material_id": m,
                    "description": row["description"],
                    "order_type": "Production Order" if is_make else "Purchase Requisition",
                    "period_start": periods[t], "quantity": planned, "uom": row["uom"],
                    "need_date": need, "release_date": release, "lead_time_days": lt,
                    "past_due": bool(past_due), "days_late": int((start - release).days) if past_due else 0,
                    "supplier_id": row["supplier_id"], "plant_id": row["plant_id"],
                    "unit_cost": float(row["unit_cost"]), "value": planned * float(row["unit_cost"]),
                })
                counter += 1
                if is_make:
                    for child, eff, _raw in graph.get(m, []):
                        if release < start:
                            ci, cd = 0, start
                        else:
                            ci, cd = _period_index(release, start, horizon), release
                        gross[child][ci] += planned * eff
                        cur = need_dt[child][ci]
                        need_dt[child][ci] = cd if cur is None else min(cur, cd)

    grid = pd.DataFrame(grid_rows)
    orders = pd.DataFrame(order_rows)
    if orders.empty:
        orders = pd.DataFrame(columns=["planned_order_id", "material_id", "description", "order_type",
                                       "period_start", "quantity", "uom", "need_date", "release_date",
                                       "lead_time_days", "past_due", "days_late", "supplier_id", "plant_id",
                                       "unit_cost", "value"])
    shortages = build_shortage_alerts(mat, orders, grid, on_hand, start, long_lead_days)
    gr = (grid.groupby("material_id")["gross_requirement"].sum().rename("gross_requirement").reset_index())
    return MRPResult(grid=grid, planned_orders=orders, shortages=shortages, gross_requirements=gr)


SHORTAGE_COLS = ["material_id", "description", "alert_type", "severity", "shortage_qty", "need_date",
                 "earliest_possible_date", "days_late", "lead_time_days", "supplier_id"]


def build_shortage_alerts(mat: pd.DataFrame, orders: pd.DataFrame, grid: pd.DataFrame, on_hand: dict,
                          start: pd.Timestamp, long_lead_days: int = 35) -> pd.DataFrame:
    """Shortage alerts:
    * Lead-time violation: a planned order should already have been released
      (release date before the run start). Expedite needed.
    * Below safety stock: current stock is under the safety stock level.
    """
    rows = []
    for o in orders[orders["past_due"]].itertuples():
        severity = "Critical" if (o.days_late > 14 or o.lead_time_days >= long_lead_days) else "High"
        rows.append({"material_id": o.material_id, "description": o.description,
                     "alert_type": "Lead-time violation (expedite)", "severity": severity,
                     "shortage_qty": o.quantity, "need_date": o.need_date,
                     "earliest_possible_date": start + pd.Timedelta(days=int(o.lead_time_days)),
                     "days_late": o.days_late, "lead_time_days": o.lead_time_days, "supplier_id": o.supplier_id})
    for m, r in mat.iterrows():
        oh = float(on_hand.get(m, 0.0))
        if r["safety_stock"] > 0 and oh < r["safety_stock"]:
            rows.append({"material_id": m, "description": r["description"], "alert_type": "Below safety stock",
                         "severity": "Warning", "shortage_qty": float(r["safety_stock"]) - oh, "need_date": start,
                         "earliest_possible_date": start + pd.Timedelta(days=int(r["lead_time_days"])),
                         "days_late": 0, "lead_time_days": int(r["lead_time_days"]),
                         "supplier_id": r["supplier_id"]})
    out = pd.DataFrame(rows, columns=SHORTAGE_COLS)
    if out.empty:
        return out
    rank = {"Critical": 0, "High": 1, "Warning": 2}
    out["_r"] = out["severity"].map(rank)
    return out.sort_values(["_r", "days_late"], ascending=[True, False]).drop(columns="_r").reset_index(drop=True)
