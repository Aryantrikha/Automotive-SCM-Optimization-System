"""Production execution simulation.

Order status lifecycle: Created -> Released -> In Progress -> Completed.
Goods issue (GI) consumes components when an order starts; goods receipt (GR)
books confirmed output into stock. Supplier receipts (GR-PO) are also posted
for purchase orders that were due before the simulation date.
This is a simplified conceptual simulation, not an SAP transaction.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from . import bom as bomlib

STATUSES = ["Created", "Released", "In Progress", "Completed"]
ALLOWED_TRANSITIONS = {"Created": "Released", "Released": "In Progress", "In Progress": "Completed"}
MOVEMENT_COLS = ["movement_id", "posting_date", "movement_type", "material_id", "quantity", "reference"]


def next_status(status: str) -> str:
    """Return the next lifecycle status; raises ValueError on invalid/terminal status."""
    if status not in STATUSES:
        raise ValueError(f"Unknown status '{status}'")
    if status not in ALLOWED_TRANSITIONS:
        raise ValueError("Order is already Completed")
    return ALLOWED_TRANSITIONS[status]


def goods_issue(order_id: str, material_id: str, qty: float, bom: pd.DataFrame, date) -> list[dict]:
    """Component consumption movements (negative quantities) for `qty` of `material_id`."""
    graph = bomlib.build_graph(bom)
    return [{"posting_date": pd.Timestamp(date), "movement_type": "GI", "material_id": child,
             "quantity": -qty * eff, "reference": order_id} for child, eff, _ in graph.get(material_id, [])]


def goods_receipt(order_id: str, material_id: str, qty: float, date) -> dict:
    """Finished/semi-finished output movement (positive quantity)."""
    return {"posting_date": pd.Timestamp(date), "movement_type": "GR", "material_id": material_id,
            "quantity": float(qty), "reference": order_id}


def simulate_execution(orders: pd.DataFrame, bom: pd.DataFrame, as_of, seed: int = 7, yield_mean: float = 0.985,
                       yield_sd: float = 0.02, release_window_days: int = 30,
                       receipts: pd.DataFrame | None = None, planned_orders: pd.DataFrame | None = None
                       ) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Simulate execution status of every production order at date `as_of`.

    Returns (orders_with_execution_fields, goods_movements).
    """
    as_of = pd.Timestamp(as_of)
    rng = np.random.default_rng(seed)
    out = orders.copy()
    out["status"] = "Created"
    out["actual_qty"] = 0.0
    out["actual_start"] = pd.NaT
    out["actual_end"] = pd.NaT
    moves: list[dict] = []

    for i in out.sort_values("start_date").index:
        o = out.loc[i]
        start, due = pd.Timestamp(o["start_date"]), pd.Timestamp(o["due_date"])
        if start > as_of:
            if (start - as_of).days <= release_window_days:
                out.loc[i, "status"] = "Released"
            continue
        delay = int(rng.choice([0, 0, 0, 0, 1, 2, 3, 5]))
        yld = float(np.clip(rng.normal(yield_mean, yield_sd), 0.9, 1.0))
        end = max(due, start + pd.Timedelta(days=1)) + pd.Timedelta(days=delay)
        out.loc[i, "actual_start"] = start
        moves += goods_issue(o["order_id"], o["material_id"], o["planned_qty"], bom, start)
        if end <= as_of:
            qty = round(o["planned_qty"] * yld)
            out.loc[i, ["status", "actual_qty", "actual_end"]] = ["Completed", qty, end]
            moves.append(goods_receipt(o["order_id"], o["material_id"], qty, end))
        else:
            progress = min(max((as_of - start).days / max((end - start).days, 1), 0.0), 1.0)
            qty = round(o["planned_qty"] * yld * progress)
            out.loc[i, ["status", "actual_qty"]] = ["In Progress", qty]
            if qty > 0:
                moves.append(goods_receipt(o["order_id"], o["material_id"], qty, as_of))

    if receipts is not None:
        for r in receipts.itertuples():
            if pd.Timestamp(r.due_date) <= as_of:
                moves.append({"posting_date": pd.Timestamp(r.due_date), "movement_type": "GR-PO",
                              "material_id": r.material_id, "quantity": float(r.quantity), "reference": r.po_id})
    if planned_orders is not None:
        bought = planned_orders[(planned_orders["order_type"] == "Purchase Requisition") & (~planned_orders["past_due"])]
        for r in bought.itertuples():
            if pd.Timestamp(r.need_date) <= as_of:
                moves.append({"posting_date": pd.Timestamp(r.need_date), "movement_type": "GR-PO",
                              "material_id": r.material_id, "quantity": float(r.quantity),
                              "reference": r.planned_order_id})

    mv = pd.DataFrame(moves, columns=MOVEMENT_COLS[1:])
    if not mv.empty:
        mv = mv.sort_values(["posting_date", "movement_type"]).reset_index(drop=True)
    mv.insert(0, "movement_id", [f"MV-{k + 1:05d}" for k in range(len(mv))])

    out["qty_variance"] = np.where(out["status"] == "Completed", out["actual_qty"] - out["planned_qty"], np.nan)
    ref_end = out["actual_end"].fillna(as_of)
    out["delay_days"] = np.where(out["status"].isin(["In Progress", "Completed"]),
                                 (ref_end - out["due_date"]).dt.days.clip(lower=0), 0)
    return out, mv


def apply_movements(inventory: pd.DataFrame, movements: pd.DataFrame) -> pd.DataFrame:
    """Return per-material stock after posting all movements (can be negative = unfulfilled issue)."""
    base = inventory.groupby("material_id")["on_hand"].sum()
    delta = movements.groupby("material_id")["quantity"].sum() if not movements.empty else pd.Series(dtype=float)
    res = pd.concat([base.rename("opening_stock"), delta.rename("net_movement")], axis=1).fillna(0.0)
    res["closing_stock"] = res["opening_stock"] + res["net_movement"]
    res["negative_stock"] = res["closing_stock"] < 0
    return res.reset_index().rename(columns={"index": "material_id"})


def execution_summary(orders: pd.DataFrame) -> pd.DataFrame:
    """Status counts with planned and actual quantity."""
    g = orders.groupby("status").agg(orders=("order_id", "count"), planned_qty=("planned_qty", "sum"),
                                     actual_qty=("actual_qty", "sum")).reindex(STATUSES).fillna(0).reset_index()
    return g


def advance_order(orders: pd.DataFrame, movements: pd.DataFrame, order_id: str, bom: pd.DataFrame, date,
                  yield_mean: float = 0.985) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Move one order to its next lifecycle status, posting goods issue / receipt as needed.

    Created -> Released: no stock movement.
    Released -> In Progress: goods issue of all direct components for the planned quantity.
    In Progress -> Completed: goods receipt of the remaining confirmed quantity (planned x yield).
    Returns updated copies of (orders, movements).
    """
    orders = orders.copy()
    movements = movements.copy()
    hit = orders.index[orders["order_id"] == order_id]
    if len(hit) != 1:
        raise ValueError(f"Order '{order_id}' not found")
    i = hit[0]
    new = next_status(orders.loc[i, "status"])
    date = pd.Timestamp(date)
    new_moves: list[dict] = []
    if new == "In Progress":
        orders.loc[i, "actual_start"] = date
        new_moves = goods_issue(order_id, orders.loc[i, "material_id"], orders.loc[i, "planned_qty"], bom, date)
    elif new == "Completed":
        final_qty = round(orders.loc[i, "planned_qty"] * yield_mean)
        remaining = final_qty - orders.loc[i, "actual_qty"]
        if remaining > 0:
            new_moves = [goods_receipt(order_id, orders.loc[i, "material_id"], remaining, date)]
        orders.loc[i, "actual_qty"] = final_qty
        orders.loc[i, "actual_end"] = date
        orders.loc[i, "qty_variance"] = final_qty - orders.loc[i, "planned_qty"]
        orders.loc[i, "delay_days"] = max((date - pd.Timestamp(orders.loc[i, "due_date"])).days, 0)
    orders.loc[i, "status"] = new
    if new_moves:
        start_id = len(movements) + 1
        add = pd.DataFrame(new_moves, columns=MOVEMENT_COLS[1:])
        add.insert(0, "movement_id", [f"MV-{start_id + k:05d}" for k in range(len(add))])
        movements = pd.concat([movements, add], ignore_index=True)
    return orders, movements
