"""Capacity planning: required vs available hours, utilisation, alerts and
a greedy load-balancing optimisation across alternative work centres.

Optimisation is a transparent greedy heuristic (no external solver needed):
each operation load is assigned to the eligible work centre (same plant and
capability group) that ends up with the lowest utilisation. An alternative
work centre may be slower (speed_factor > 1 means more hours per unit).
"""
from __future__ import annotations

import pandas as pd


def available_hours(work_centres: pd.DataFrame, working_days: int = 22) -> pd.DataFrame:
    """Monthly available hours = machines x shifts x hours/shift x days x efficiency x availability."""
    wc = work_centres.copy()
    wc["available_hours"] = (wc["machines"] * wc["shifts_per_day"] * wc["hours_per_shift"] * working_days
                             * wc["efficiency"] * wc["availability"])
    return wc


def operation_loads(orders: pd.DataFrame, routings: pd.DataFrame) -> pd.DataFrame:
    """Required hours per order operation: setup + qty x run time / 60 (at speed factor 1.0)."""
    if orders.empty:
        return pd.DataFrame(columns=["order_id", "material_id", "op_no", "operation", "work_centre_id", "wc_group",
                                     "plant_id", "period_start", "base_hours", "setup_hrs"])
    m = orders.merge(routings, on="material_id", how="inner")
    m["run_hours"] = m["planned_qty"] * m["run_min_per_unit"] / 60.0
    m["base_hours"] = m["setup_hrs"] + m["run_hours"]
    m["period_start"] = m["start_date"].dt.to_period("M").dt.to_timestamp()
    return m[["order_id", "material_id", "op_no", "operation", "work_centre_id", "wc_group", "plant_id",
              "period_start", "base_hours", "setup_hrs", "run_hours"]]


def utilisation_table(loads: pd.DataFrame, work_centres: pd.DataFrame, periods: list, working_days: int,
                      warn: float = 0.85, over: float = 1.0, hours_col: str = "hours",
                      wc_col: str = "work_centre_id") -> pd.DataFrame:
    """Required vs available hours and utilisation for every work centre and period."""
    wc = available_hours(work_centres, working_days)[["work_centre_id", "name", "plant_id", "wc_group",
                                                      "available_hours"]]
    req = loads.groupby([wc_col, "period_start"])[hours_col].sum().rename("required_hours").reset_index()
    req = req.rename(columns={wc_col: "work_centre_id"})
    full = pd.MultiIndex.from_product([wc["work_centre_id"], periods], names=["work_centre_id", "period_start"]).to_frame(index=False)
    out = full.merge(wc, on="work_centre_id").merge(req, on=["work_centre_id", "period_start"], how="left")
    out["required_hours"] = out["required_hours"].fillna(0.0)
    out["utilisation"] = out["required_hours"] / out["available_hours"]
    out["status"] = pd.cut(out["utilisation"], bins=[-1, warn, over, 1e9],
                           labels=["OK", "Warning", "Overloaded"], right=True).astype(str)
    out["overload_hours"] = (out["required_hours"] - out["available_hours"]).clip(lower=0)
    return out


def baseline_capacity(orders, routings, work_centres, periods, working_days=22, warn=0.85, over=1.0):
    """Capacity check with every operation on its primary work centre."""
    loads = operation_loads(orders, routings)
    loads = loads.assign(hours=loads["base_hours"])
    return loads, utilisation_table(loads, work_centres, periods, working_days, warn, over)


def over_capacity_alerts(util: pd.DataFrame) -> pd.DataFrame:
    """Rows where utilisation exceeds 100 %."""
    a = util[util["status"] == "Overloaded"].copy()
    return a.sort_values("utilisation", ascending=False)[
        ["work_centre_id", "name", "plant_id", "period_start", "required_hours", "available_hours",
         "utilisation", "overload_hours"]].reset_index(drop=True)


def optimise_allocation(loads: pd.DataFrame, work_centres: pd.DataFrame, periods: list, working_days: int = 22,
                        warn: float = 0.85, over: float = 1.0, chunks: int = 10) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Greedy load balancing across eligible work centres (orders may be split).

    Each operation's run time is cut into `chunks` equal slices. A slice stays on
    the primary work centre while that centre remains at or below the warning
    threshold; otherwise it goes to the eligible centre (same plant and capability
    group) that would end up least utilised. Opening an additional work centre for
    an operation costs one extra setup. Slower alternates (speed_factor > 1) need
    proportionally more run hours.

    Returns (assignments, utilisation_table).
    """
    wc = available_hours(work_centres, working_days).set_index("work_centre_id")
    rows = []
    for period, grp in loads.groupby("period_start"):
        used = {w: 0.0 for w in wc.index}
        for r in grp.sort_values("base_hours", ascending=False).itertuples():
            plant = wc.loc[r.work_centre_id, "plant_id"]
            eligible = wc[(wc["wc_group"] == r.wc_group) & (wc["plant_id"] == plant)]
            prim_speed = wc.loc[r.work_centre_id, "speed_factor"]
            per_wc: dict[str, float] = {}
            for _ in range(chunks):
                options = {}
                for wid, e in eligible.iterrows():
                    hrs = r.run_hours / chunks * e["speed_factor"] / prim_speed
                    if wid not in per_wc:
                        hrs += r.setup_hrs
                    options[wid] = (hrs, (used[wid] + hrs) / e["available_hours"])
                prim = options[r.work_centre_id]
                if prim[1] <= warn:
                    pick = r.work_centre_id
                else:
                    pick = min(options, key=lambda w: (options[w][1], w != r.work_centre_id))
                used[pick] += options[pick][0]
                per_wc[pick] = per_wc.get(pick, 0.0) + options[pick][0]
            for wid, hrs in per_wc.items():
                rows.append({"order_id": r.order_id, "material_id": r.material_id, "op_no": r.op_no,
                             "operation": r.operation, "primary_work_centre": r.work_centre_id,
                             "assigned_work_centre": wid, "period_start": period, "hours": hrs})
    assign = pd.DataFrame(rows, columns=["order_id", "material_id", "op_no", "operation", "primary_work_centre",
                                         "assigned_work_centre", "period_start", "hours"])
    util = utilisation_table(assign, work_centres, periods, working_days, warn, over, hours_col="hours",
                             wc_col="assigned_work_centre")
    return assign, util


def compare_utilisation(before: pd.DataFrame, after: pd.DataFrame) -> pd.DataFrame:
    """Per work centre: peak utilisation before vs after optimisation."""
    b = before.groupby(["work_centre_id", "name"])["utilisation"].max().rename("peak_before")
    a = after.groupby(["work_centre_id", "name"])["utilisation"].max().rename("peak_after")
    return pd.concat([b, a], axis=1).reset_index()
