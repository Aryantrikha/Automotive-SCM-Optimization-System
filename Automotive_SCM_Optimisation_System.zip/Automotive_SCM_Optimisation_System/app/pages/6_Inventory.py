import plotly.express as px
import streamlit as st

import common as c
from automotive_scm import inventory as invlib

c.setup_page("Inventory", "📦")
res = c.header("Inventory", "On-hand, safety stock, reorder point, valuation, ageing and shortage status")
inv = res["inventory_status"]

m = st.columns(4)
m[0].metric("Inventory value", c.money(inv["stock_value"].sum()))
m[1].metric("Turnover (x / year)", f"{invlib.inventory_turnover(inv):.1f}")
m[2].metric("Below safety / stockout", int(inv["status"].isin(["Below safety stock", "Stockout"]).sum()))
m[3].metric("Reorder needed", int((inv["status"] == "Reorder").sum()))

c1, c2 = st.columns(2)
with c1:
    val = invlib.inventory_valuation(inv)
    st.plotly_chart(c.style_fig(px.pie(val, names="material_type", values="stock_value", hole=0.45,
                                       title="Stock value by material type")))
with c2:
    st.plotly_chart(c.style_fig(px.bar(invlib.ageing_profile(inv), x="ageing_bucket", y="stock_value",
                                       title="Stock value by age since last movement", labels={"ageing_bucket": ""})))

st.subheader("Stock position")
f1, f2 = st.columns(2)
status = f1.multiselect("Status", sorted(inv["status"].unique()), default=sorted(inv["status"].unique()))
types = f2.multiselect("Material type", sorted(inv["material_type"].unique()), default=sorted(inv["material_type"].unique()))
f = inv[inv["status"].isin(status) & inv["material_type"].isin(types)].copy()
f["days_of_cover"] = f["days_of_cover"].replace([float("inf")], None).round(1)
st.dataframe(f.round(1), hide_index=True)
c.download_button(inv, "inventory_status.csv", "dl_inv")

st.subheader("Stock vs safety stock and reorder point")
comp = f[f["material_type"] != "FERT"].melt(id_vars=["material_id"], value_vars=["on_hand", "safety_stock", "reorder_point"],
                                            var_name="measure", value_name="units")
st.plotly_chart(c.style_fig(px.bar(comp, x="material_id", y="units", color="measure", barmode="group", log_y=True,
                                   labels={"material_id": ""}, title="Log scale"), 420))

st.subheader("Open scheduled receipts (purchase orders)")
sr = res["data"]["scheduled_receipts"].copy()
sr["due_date"] = sr["due_date"].dt.strftime("%d %b %Y")
st.dataframe(sr, hide_index=True)
