"""Automotive SCM & Production Planning Optimisation System.

An independent, company-neutral Python simulation of automotive production
planning (forecasting, BOM explosion, MRP, capacity, supplier and execution
tracking). All data is synthetic. This is NOT an SAP implementation.
"""

__version__ = "1.0.0"
